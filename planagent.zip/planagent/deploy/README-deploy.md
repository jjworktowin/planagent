# 部署上线（宝塔面板）

## 一、总体结构

```
你的手机 / 浏览器
      │  https://你的域名
      ▼
   Nginx（宝塔站点 + SSL 证书）
      │  http://127.0.0.1:8765
      ▼
   PlanAgent（systemd 服务，只监听本机端口）
      ├─ DeepSeek API
      └─ 企业微信机器人（推送提醒 + 打卡链接）
```

服务只监听 `127.0.0.1`，对外统一走 Nginx，HTTPS、域名、证书都由宝塔负责，Python 服务不碰 443。

## 二、准备

1. **域名**：准备一个域名（例如 `plan.你的域名.com`），在域名服务商处添加 A 记录指向服务器公网 IP。
2. **安全组**：云服务器控制台的安全组放行 `80` 和 `443`（8765 不用对外开放）。
3. **Python 版本**：确认服务器 Python ≥ 3.10（宝塔软件商店可安装）。

## 三、上传项目

宝塔 → **文件** → 进入 `/www/wwwroot/` → 新建目录 `planagent` → 上传 `planagent.zip` → 右键解压。

> ⚠️ **更新已部署的项目时**：包里的 `data/config.json` 是空密钥模板，直接解压覆盖会把服务器上
> 已经填好的密钥、企业微信地址和计划数据一起冲掉。正确做法是先备份：
>
> ```bash
> cd /www/wwwroot/planagent && cp -a data data.bak.$(date +%F)
> ```
>
> 解压后再把 `data.bak.*` 里的 `config.json`、`plans.json` 挪回 `data/`，然后重启项目。

## 四、一键部署

宝塔 → **终端**，执行：

```bash
cd /www/wwwroot/planagent
bash deploy/bootstrap.sh
```

脚本自动完成：装系统依赖 → 建虚拟环境 → 装 Python 依赖 → 注册 `planagent` 系统服务 → 开机自启 → 启动并自检。

```bash
journalctl -u planagent -f          # 看日志
PORT=9000 bash deploy/bootstrap.sh  # 换端口（记得同步改 Nginx 反代）
```

## 五、绑定域名 + 反向代理 + HTTPS

1. **网站 → 添加站点**：域名填 `plan.你的域名.com`，PHP 版本选「纯静态」。
2. 进入站点 → **反向代理 → 添加反向代理**：
   - 代理名称：`planagent`
   - 目标 URL：`http://127.0.0.1:8765`
   - 发送域名：`$host`
3. 站点 → **SSL → Let's Encrypt** 申请证书 → 开启「强制 HTTPS」。
4. 打开 `https://plan.你的域名.com`，看到「计划智能体」界面即成功。

> 反向代理的 `proxy_read_timeout` 建议调到 300 秒：思考模式有时要十几秒才回复。

## 六、上线后必做的三项配置

打开 `https://你的域名` → 左侧 **设置**：

1. **DeepSeek 配置**：填 API Key → 点「测试连接」确认可用。
2. **企业微信机器人**：填 Webhook → 点「发送测试消息」确认群里能收到。
3. **提醒与打卡 → 打卡链接使用的外网地址**：填 `https://你的域名`。
   这一步最关键——手机点打卡链接必须能打开，局域网 IP 在公网没用。

最后点「复制示例打卡链接」发到手机试一下，能打开签到页就正式上线了。

## 七、日常运维

```bash
systemctl status planagent      # 状态
systemctl restart planagent     # 重启
journalctl -u planagent -f      # 实时日志
```

数据都在 `data/` 目录：

| 文件 | 内容 |
| --- | --- |
| `config.json` | DeepSeek 密钥、企业微信地址、打卡地址、访问密码 |
| `plans.json` | 所有计划 + 打卡记录 |
| `state.json` | 提醒推送去重记录 |
| `sessions.json` | 对话历史 |

备份只需打包 `data/` 目录。

## 八、安全建议

- 公网上线**务必开启访问密码**（设置 → 访问密码），否则任何知道域名的人都能看你的计划、改配置、消耗 DeepSeek 额度。
- 打卡链接（`/checkin`）不受访问密码限制，因为要在企业微信里直接点开。
- 如果暂时不想对外，`systemctl stop planagent` 即可，数据不丢。
