#!/usr/bin/env bash
# 计划智能体 · 一键部署脚本（Ubuntu / Debian / CentOS / 宝塔 Linux）
#
# 用法（在项目目录里执行）：
#   bash deploy/bootstrap.sh
# 或指定目录/端口：
#   APP_DIR=/www/wwwroot/planagent PORT=8765 bash deploy/bootstrap.sh
set -euo pipefail

APP_DIR="${APP_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
SERVICE="${SERVICE:-planagent}"
PORT="${PORT:-8765}"
HOST="${HOST:-127.0.0.1}"

ok()  { echo -e "\033[32m[planagent]\033[0m $*"; }
die() { echo -e "\033[31m[planagent]\033[0m $*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "请用 root 执行（宝塔终端默认就是 root）"
[[ -f "$APP_DIR/requirements.txt" ]] || die "没找到 $APP_DIR/requirements.txt，请先上传项目"

cd "$APP_DIR"

# ---------- 1. 系统依赖 ----------
if command -v apt-get >/dev/null 2>&1; then
  ok "安装系统依赖（apt）"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y -qq python3 python3-venv python3-pip ca-certificates >/dev/null
elif command -v dnf >/dev/null 2>&1 || command -v yum >/dev/null 2>&1; then
  ok "安装系统依赖（yum/dnf）"
  PKG=$(command -v dnf || command -v yum)
  $PKG install -y python3 python3-pip ca-certificates >/dev/null
else
  die "没有识别到 apt / yum，请手动安装 python3 和 pip"
fi

command -v python3 >/dev/null 2>&1 || die "python3 安装失败"

PY_VER=$(python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])')
ok "python3 版本：$PY_VER"

python3 - <<'PY' || die "需要 Python 3.10 及以上，请到宝塔软件商店安装更高版本 Python"
import sys
sys.exit(0 if sys.version_info[:2] >= (3, 10) else 1)
PY

# ---------- 2. 虚拟环境 + 依赖 ----------
if [[ ! -x ".venv/bin/python" ]]; then
  ok "创建虚拟环境 .venv"
  python3 -m venv .venv
fi
ok "安装 Python 依赖"
.venv/bin/pip install -q -U pip
.venv/bin/pip install -q -r requirements.txt

# ---------- 3. 注册为系统服务 ----------
ok "写入 systemd 服务 /etc/systemd/system/$SERVICE.service"
cat > "/etc/systemd/system/$SERVICE.service" <<EOF
[Unit]
Description=PlanAgent - DeepSeek 计划智能体
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
Environment=PYTHONIOENCODING=utf-8
Environment=PYTHONUNBUFFERED=1
ExecStart=$APP_DIR/.venv/bin/python $APP_DIR/main.py --host $HOST --port $PORT --no-browser
Restart=always
RestartSec=5
StandardOutput=append:$APP_DIR/data/service.log
StandardError=append:$APP_DIR/data/service.err.log

[Install]
WantedBy=multi-user.target
EOF

mkdir -p "$APP_DIR/data"
systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null
systemctl restart "$SERVICE"
sleep 2

# ---------- 4. 自检 ----------
if systemctl is-active --quiet "$SERVICE"; then
  ok "服务已启动 ✅"
else
  journalctl -u "$SERVICE" -n 30 --no-pager || true
  die "服务启动失败，请看上面的日志"
fi

if command -v curl >/dev/null 2>&1; then
  for _ in 1 2 3 4 5; do
    if curl -fsS "http://127.0.0.1:$PORT/api/state" >/dev/null 2>&1; then
      ok "接口自检通过：http://127.0.0.1:$PORT/api/state"
      break
    fi
    sleep 2
  done
fi

cat <<EOF

============================================================
部署完成 🎉
   项目目录   : $APP_DIR
   监听地址   : $HOST:$PORT（只对本机开放，请用宝塔反向代理对外）
   服务名     : $SERVICE
   重启服务   : systemctl restart $SERVICE
   查看日志   : journalctl -u $SERVICE -f

下一步（在宝塔面板里做）：
   1. 网站 → 添加站点，绑定你的域名（如 plan.你的域名.com）
   2. 站点设置 → 反向代理 → 目标 URL 填 http://127.0.0.1:$PORT
   3. 站点设置 → SSL → Let's Encrypt 申请证书，并开启强制 HTTPS
   4. 打开 https://你的域名 → 设置 → 填 DeepSeek 密钥、企业微信机器人，
      并把「打卡链接使用的外网地址」填 https://你的域名
============================================================
EOF
