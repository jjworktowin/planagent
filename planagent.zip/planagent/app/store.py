"""计划数据存储。

所有计划统一保存在一个文件里：data/plans.json
结构：{"version": 1, "updated_at": "...", "plans": [ ... ]}

打卡采用「续火花」逻辑：
  · 今天已经打过卡 -> 不重复计数，火花保持
  · 昨天打过卡，今天再打 -> 连续天数 +1
  · 中间断了（隔了 1 天以上）-> 火花熄灭，连续天数从 1 重新点燃
"""

from __future__ import annotations

from datetime import date, timedelta
from typing import Any, Iterable

from . import paths

ALLOWED_STATUS = {"active", "paused", "done", "archived"}


def empty_checkin() -> dict[str, Any]:
    return {
        "streak": 0,        # 当前连续打卡天数（火花）
        "best": 0,          # 最长连续打卡天数
        "total": 0,         # 累计打卡天数
        "last_date": None,  # 最近一次打卡日期
        "history": [],      # 打卡日期列表
        "broken": 0,        # 火花熄灭（断签）次数
    }


def normalize_time_list(value: Any, fallback: Iterable[str] = ("09:00",)) -> list[str]:
    result: list[str] = []
    if isinstance(value, str):
        raw: list[Any] = [p for p in value.replace("，", ",").replace("、", ",").replace(" ", ",").split(",")]
    elif isinstance(value, (list, tuple, set)):
        raw = list(value)
    else:
        raw = []
    for item in raw:
        normalized = paths.normalize_hhmm(item)
        if normalized and normalized not in result:
            result.append(normalized)
    if not result:
        result = [paths.normalize_hhmm(x, "09:00") for x in fallback]
    return sorted(set(result))[:6]


def normalize_tasks(value: Any, days: int) -> list[dict[str, Any]]:
    tasks: list[dict[str, Any]] = []
    if not isinstance(value, (list, tuple)):
        return tasks
    for index, item in enumerate(value):
        if isinstance(item, str):
            item = {"title": item}
        if not isinstance(item, dict):
            continue
        title = str(item.get("title") or item.get("name") or item.get("content") or "").strip()
        if not title:
            continue
        try:
            day = int(item.get("day") or 0)
        except (TypeError, ValueError):
            day = 0
        if day != 0:
            day = max(1, min(days or 1, day))
        tasks.append(
            {
                "id": str(item.get("id") or paths.new_id("task")),
                "day": day,  # 0 = 每天
                "time": paths.normalize_hhmm(item.get("time"), "") or "",
                "title": title,
                "detail": str(item.get("detail") or item.get("note") or "").strip(),
            }
        )
        if index > 500:  # 防护
            break
    return tasks


class PlanStore:
    def __init__(self, path=None):
        self.path = path or paths.PLANS_PATH
        self._data: dict[str, Any] = {"version": 1, "updated_at": paths.now_str(), "plans": []}
        self.load()

    # ---------------- 读写 ----------------
    def load(self) -> None:
        data = paths.read_json(self.path, None)
        if not isinstance(data, dict) or not isinstance(data.get("plans"), list):
            data = {"version": 1, "updated_at": paths.now_str(), "plans": []}
        self._data = data

    def save(self) -> None:
        self._data["updated_at"] = paths.now_str()
        paths.write_json(self.path, self._data)

    @property
    def plans(self) -> list[dict[str, Any]]:
        return self._data["plans"]

    # ---------------- 查询 ----------------
    def list_plans(self, include_archived: bool = False) -> list[dict[str, Any]]:
        items = [p for p in self.plans if include_archived or p.get("status") != "archived"]
        items.sort(key=lambda p: (p.get("status") != "active", p.get("created_at") or ""))
        return items

    def get(self, plan_id: str) -> dict[str, Any] | None:
        for plan in self.plans:
            if plan.get("id") == plan_id:
                return plan
        return None

    def summary(self) -> list[dict[str, Any]]:
        out = []
        for plan in self.list_plans():
            view = plan_view(plan)
            out.append(
                {
                    "id": plan["id"],
                    "title": plan.get("title"),
                    "days": plan.get("days"),
                    "start_date": plan.get("start_date"),
                    "reminder_times": plan.get("reminder_times"),
                    "status": plan.get("status"),
                    "notify_enabled": plan.get("notify_enabled", True),
                    "streak": plan.get("checkin", {}).get("streak", 0),
                    "best": plan.get("checkin", {}).get("best", 0),
                    "progress": view["progress"],
                    "today_index": view["today_index"],
                    "today_tasks": view["today_tasks"],
                    "checked_in_today": view["checked_in_today"],
                }
            )
        return out

    # ---------------- 增删改 ----------------
    def create(self, payload: dict[str, Any]) -> dict[str, Any]:
        plan = self._build(payload)
        plan["id"] = paths.new_id("plan")
        plan["created_at"] = paths.now_str()
        plan["updated_at"] = plan["created_at"]
        plan["checkin"] = empty_checkin()
        self.plans.append(plan)
        self.save()
        return plan

    def update(self, plan_id: str, payload: dict[str, Any]) -> dict[str, Any] | None:
        plan = self.get(plan_id)
        if not plan:
            return None
        rebuilt = self._build({**plan, **{k: v for k, v in payload.items() if v is not None}})
        rebuilt["id"] = plan["id"]
        rebuilt["created_at"] = plan.get("created_at") or paths.now_str()
        rebuilt["updated_at"] = paths.now_str()
        rebuilt["checkin"] = plan.get("checkin") or empty_checkin()
        index = self.plans.index(plan)
        self.plans[index] = rebuilt
        self.save()
        return rebuilt

    def delete(self, plan_id: str) -> bool:
        plan = self.get(plan_id)
        if not plan:
            return False
        self.plans.remove(plan)
        self.save()
        return True

    def set_status(self, plan_id: str, status: str) -> dict[str, Any] | None:
        if status not in ALLOWED_STATUS:
            return None
        return self.update(plan_id, {"status": status})

    def _build(self, payload: dict[str, Any]) -> dict[str, Any]:
        start = paths.parse_date(payload.get("start_date")) or paths.today()
        try:
            days = int(payload.get("days") or 1)
        except (TypeError, ValueError):
            days = 1
        days = max(1, min(365, days))

        tasks = normalize_tasks(payload.get("tasks"), days)
        reminder_times = normalize_time_list(
            payload.get("reminder_times") or payload.get("remind_times")
        )
        # 任务里带了时间、但计划层没有的时间，也加入提醒
        for task in tasks:
            if task["time"] and task["time"] not in reminder_times:
                reminder_times.append(task["time"])
        reminder_times = sorted(set(reminder_times))[:6] or ["09:00"]

        status = str(payload.get("status") or "active")
        if status not in ALLOWED_STATUS:
            status = "active"

        return {
            "id": payload.get("id"),
            "title": (str(payload.get("title") or "未命名计划").strip())[:80],
            "goal": str(payload.get("goal") or "").strip(),
            "notes": str(payload.get("notes") or "").strip(),
            "start_date": start.strftime(paths.DATE_FMT),
            "days": days,
            "reminder_times": reminder_times,
            "notify_enabled": bool(payload.get("notify_enabled", True)),
            "webhook": str(payload.get("webhook") or "").strip(),
            "tasks": tasks,
            "status": status,
            "source": str(payload.get("source") or "manual"),
        }

    # ---------------- 打卡 ----------------
    def tasks_of_day(self, plan: dict[str, Any], day_index: int) -> list[dict[str, Any]]:
        return [
            t
            for t in plan.get("tasks", [])
            if int(t.get("day") or 0) in (0, day_index)
        ]

    def checkin(self, plan_id: str, day: str | None = None) -> dict[str, Any]:
        """给计划打卡（默认今天），返回结果描述。"""
        plan = self.get(plan_id)
        if not plan:
            return {"ok": False, "error": "计划不存在"}

        day = day or paths.today_str()
        day_date = paths.parse_date(day)
        if not day_date:
            return {"ok": False, "error": "日期格式错误"}
        day = day_date.strftime(paths.DATE_FMT)

        checkin = plan.setdefault("checkin", empty_checkin())
        history: list[str] = list(checkin.get("history") or [])
        streak = int(checkin.get("streak") or 0)
        best = int(checkin.get("best") or 0)

        start = paths.parse_date(plan.get("start_date")) or paths.today()
        day_index = (day_date - start).days + 1

        if day in history:
            return {
                "ok": True,
                "already": True,
                "plan_id": plan_id,
                "title": plan.get("title"),
                "date": day,
                "day_index": day_index,
                "days": plan.get("days"),
                "streak": streak,
                "best": best,
                "total": int(checkin.get("total") or 0),
                "message": f"今天（{day}）已经打过卡啦，火花保持在 {streak} 天 🔥",
            }

        last = paths.parse_date(checkin.get("last_date"))
        broken = int(checkin.get("broken") or 0)
        if last and (day_date - last).days == 1:
            streak += 1
        elif last and (day_date - last).days <= 0:
            streak = max(streak, 1)
        else:
            if streak > 0:
                broken += 1
            streak = 1

        best = max(best, streak)
        history.append(day)
        history = sorted(set(history))
        checkin.update(
            {
                "streak": streak,
                "best": best,
                "total": int(checkin.get("total") or 0) + 1,
                "last_date": day,
                "history": history,
                "broken": broken,
            }
        )
        if streak > 1:
            message = f"续火花成功！连续打卡 {streak} 天 🔥"
        elif broken and streak == 1:
            message = "火花重新点燃，连续打卡 1 天 🔥 明天继续别断哦"
        else:
            message = "打卡成功，火花点燃！连续打卡 1 天 🔥"

        # 全部天数都打卡 -> 计划完成
        if len(history) >= int(plan.get("days") or 1) and plan.get("status") == "active":
            plan["status"] = "done"
            message += "  🎉 这个计划的所有天数都完成啦！"

        plan["updated_at"] = paths.now_str()
        self.save()
        return {
            "ok": True,
            "already": False,
            "plan_id": plan_id,
            "title": plan.get("title"),
            "date": day,
            "day_index": day_index,
            "days": plan.get("days"),
            "streak": streak,
            "best": best,
            "total": checkin["total"],
            "broken": broken,
            "message": message,
        }


def plan_view(plan: dict[str, Any]) -> dict[str, Any]:
    """把计划渲染成界面/提醒用的「计划表」。"""
    start = paths.parse_date(plan.get("start_date")) or paths.today()
    days = int(plan.get("days") or 1)
    today_d = paths.today()
    history = set(plan.get("checkin", {}).get("history") or [])
    tasks_all = plan.get("tasks", [])
    daily_tasks = [t for t in tasks_all if int(t.get("day") or 0) == 0]

    rows = []
    for i in range(days):
        the_date = start + timedelta(days=i)
        day_tasks = [t for t in tasks_all if int(t.get("day") or 0) == i + 1]
        if the_date in {paths.parse_date(h) for h in history if h}:
            state = "done"
        elif the_date == today_d:
            state = "today"
        elif the_date < today_d:
            state = "missed"
        else:
            state = "upcoming"
        rows.append(
            {
                "day_index": i + 1,
                "date": the_date.strftime(paths.DATE_FMT),
                "weekday": paths.weekday_cn(the_date),
                "tasks": [dict(t) for t in day_tasks],
                "daily_tasks": [dict(t) for t in daily_tasks],
                "state": state,
                "is_today": the_date == today_d,
            }
        )

    done = len([r for r in rows if r["state"] == "done"])
    today_index = (today_d - start).days + 1
    today_row = next((r for r in rows if r["is_today"]), None)
    today_tasks = []
    if today_row:
        today_tasks = today_row["daily_tasks"] + today_row["tasks"]
    elif 1 <= today_index <= days:
        today_tasks = daily_tasks

    return {
        "plan": plan,
        "rows": rows,
        "daily_tasks": daily_tasks,
        "today_index": today_index,
        "today_tasks": today_tasks,
        "checked_in_today": today_d.strftime(paths.DATE_FMT) in history,
        "progress": {
            "done": done,
            "total": days,
            "percent": round(done / days * 100, 1) if days else 0.0,
        },
    }
