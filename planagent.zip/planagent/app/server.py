"""FastAPI 服务：网页界面 + REST 接口 + 打卡链接。"""

from __future__ import annotations

from typing import Any

from fastapi import Body, FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import auth, checkin, notifier, paths
from .agent import PlannerAgent
from .config import ConfigStore
from .scheduler import ReminderScheduler
from .store import PlanStore, plan_view

STARTED_AT = paths.now_str()


def create_app(config: ConfigStore | None = None) -> FastAPI:
    paths.ensure_dirs()
    config = config or ConfigStore()
    store = PlanStore()
    agent = PlannerAgent(config, store)
    scheduler = ReminderScheduler(config, store)
    scheduler.start()

    app = FastAPI(title="计划智能体 PlanAgent", docs_url="/api/docs", redoc_url=None)
    app.mount("/static", StaticFiles(directory=str(paths.STATIC_DIR)), name="static")

    # ==================== 访问口令 ====================
    @app.middleware("http")
    async def access_guard(request, call_next):  # noqa: ANN001
        password = config.get("access_password", "")
        if not password or auth.is_public_path(request.url.path):
            return await call_next(request)
        token = request.cookies.get(auth.COOKIE_NAME) or request.query_params.get("k")
        if auth.verify(password, token or ""):
            return await call_next(request)
        if request.url.path.startswith("/api/"):
            return JSONResponse(
                {"ok": False, "error": "未登录：请先输入访问口令", "need_login": True},
                status_code=401,
            )
        return FileResponse(paths.STATIC_DIR / "login.html")

    @app.post("/login")
    def do_login(payload: dict[str, Any] = Body(...)) -> Any:
        password = config.get("access_password", "")
        if not password:
            return {"ok": True, "redirect": "/"}
        if not auth.check_password(password, str(payload.get("password") or "")):
            return JSONResponse({"ok": False, "error": "访问口令不正确"}, status_code=401)
        response = JSONResponse({"ok": True, "redirect": "/"})
        response.set_cookie(
            auth.COOKIE_NAME,
            auth.auth_token(password),
            max_age=auth.COOKIE_MAX_AGE,
            httponly=True,
            samesite="lax",
        )
        return response

    @app.post("/logout")
    def do_logout() -> Any:
        response = JSONResponse({"ok": True})
        response.delete_cookie(auth.COOKIE_NAME)
        return response

    # ==================== 页面 ====================
    @app.get("/")
    def index() -> FileResponse:
        return FileResponse(paths.STATIC_DIR / "index.html")

    @app.get("/checkin")
    def checkin_page(t: str = Query(default="")) -> FileResponse:
        """打卡链接落到这里；页面会用 JS 自动提交签到，一键续火花。"""
        return FileResponse(paths.STATIC_DIR / "checkin.html")

    @app.get("/favicon.ico")
    def favicon() -> HTMLResponse:
        return HTMLResponse(status_code=204)

    # ==================== 总览 ====================
    @app.get("/api/state")
    def api_state() -> dict[str, Any]:
        return {
            "ok": True,
            "today": paths.today_str(),
            "now": paths.now_str(),
            "config": config.public(),
            "server": {
                "base_url": config.effective_base_url(),
                "lan_ip": paths.get_lan_ip(),
                "port": config.get_int("port", 8765),
                "started_at": STARTED_AT,
                "deepseek_ready": config.deepseek_ready(),
                "notify_ready": config.notify_ready(),
            },
            "plans": store.summary(),
            "scheduler": {
                "last_tick": scheduler.last_tick,
                "next": scheduler.next_reminders(),
                "error": scheduler.last_error,
            },
        }

    # ==================== 计划 ====================
    @app.get("/api/plans")
    def list_plans() -> dict[str, Any]:
        return {"ok": True, "plans": store.summary()}

    @app.post("/api/plans")
    def create_plan(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        plan = store.create({**payload, "source": "manual"})
        result = _view(plan, config)
        paths.log(f"手动创建计划：{plan['title']}")
        return {"ok": True, **result}

    @app.get("/api/plans/{plan_id}")
    def get_plan(plan_id: str) -> dict[str, Any]:
        plan = store.get(plan_id)
        if not plan:
            raise HTTPException(status_code=404, detail="计划不存在")
        return {"ok": True, **_view(plan, config)}

    @app.put("/api/plans/{plan_id}")
    def update_plan(plan_id: str, payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        plan = store.update(plan_id, payload)
        if not plan:
            raise HTTPException(status_code=404, detail="计划不存在")
        return {"ok": True, **_view(plan, config)}

    @app.delete("/api/plans/{plan_id}")
    def delete_plan(plan_id: str) -> dict[str, Any]:
        if not store.delete(plan_id):
            raise HTTPException(status_code=404, detail="计划不存在")
        return {"ok": True}

    @app.post("/api/plans/{plan_id}/status")
    def set_status(plan_id: str, payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        plan = store.set_status(plan_id, str(payload.get("status") or ""))
        if not plan:
            raise HTTPException(status_code=400, detail="状态不合法或计划不存在")
        return {"ok": True, **_view(plan, config)}

    @app.post("/api/plans/{plan_id}/notify")
    def set_notify(plan_id: str, payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        plan = store.update(plan_id, {"notify_enabled": bool(payload.get("enabled", True))})
        if not plan:
            raise HTTPException(status_code=404, detail="计划不存在")
        return {"ok": True, **_view(plan, config)}

    @app.get("/api/plans/{plan_id}/link")
    def plan_link(plan_id: str, date: str | None = None) -> dict[str, Any]:
        plan = store.get(plan_id)
        if not plan:
            raise HTTPException(status_code=404, detail="计划不存在")
        return {"ok": True, "url": checkin.checkin_url(config, plan_id, date), "date": date or paths.today_str()}

    @app.post("/api/plans/{plan_id}/push")
    def push_now(plan_id: str, payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
        plan = store.get(plan_id)
        if not plan:
            raise HTTPException(status_code=404, detail="计划不存在")
        slot = payload.get("slot") or (plan.get("reminder_times") or ["09:00"])[0]
        result = scheduler.push_reminder(plan, slot)
        return {"ok": bool(result.get("ok")), "detail": result}

    # ==================== 打卡 ====================
    @app.post("/api/plans/{plan_id}/checkin")
    def manual_checkin(plan_id: str, payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
        result = store.checkin(plan_id, payload.get("date"))
        if not result.get("ok"):
            raise HTTPException(status_code=400, detail=result.get("error") or "打卡失败")
        return result

    @app.get("/api/checkin/peek")
    def peek(token: str = Query(...)) -> dict[str, Any]:
        payload = checkin.verify_token(config.get("checkin_token_secret", ""), token)
        if not payload:
            return {"ok": False, "error": "链接已失效或无效"}
        plan = store.get(payload.get("p") or "")
        if not plan:
            return {"ok": False, "error": "计划不存在或已被删除"}
        already = (payload.get("d") in set(plan.get("checkin", {}).get("history") or []))
        return {
            "ok": True,
            "already": already,
            "title": plan.get("title"),
            "date": payload.get("d"),
            "streak": plan.get("checkin", {}).get("streak", 0),
        }

    @app.post("/api/checkin/confirm")
    def confirm_checkin(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        token = str(payload.get("token") or "")
        data = checkin.verify_token(config.get("checkin_token_secret", ""), token)
        if not data:
            return {"ok": False, "error": "打卡链接已失效，请让计划智能体重新推送。"}
        result = store.checkin(data.get("p"), data.get("d"))
        if result.get("ok"):
            result["source"] = "link"
        return result

    # ==================== 配置 ====================
    @app.get("/api/config")
    def get_config() -> dict[str, Any]:
        return {"ok": True, "config": config.public()}

    @app.post("/api/config")
    def update_config(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        changed = config.update(payload)
        if any(k.startswith("deepseek") for k in changed):
            agent.reset_clients()
        return {"ok": True, "changed": sorted(changed.keys()), "config": config.public()}

    @app.post("/api/config/test-deepseek")
    def test_deepseek(payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
        prompt = payload.get("prompt") or "用一句话确认你在线，并说出今天的日期。"
        try:
            client = agent.client()
        except RuntimeError as exc:
            return {"ok": False, "error": str(exc)}
        request: dict[str, Any] = {
            "model": config.get("deepseek_model", "deepseek-flash"),
            "messages": [{"role": "user", "content": prompt}],
        }
        if config.get_bool("thinking_enabled", True):
            request["reasoning_effort"] = config.get("reasoning_effort", "high")
            request["extra_body"] = {"thinking": {"type": "enabled"}}
        try:
            response = client.chat.completions.create(**request)
            message = response.choices[0].message
            return {
                "ok": True,
                "model": config.get("deepseek_model"),
                "reply": (message.content or "").strip()[:400],
                "reasoning": (getattr(message, "reasoning_content", "") or "")[:400],
            }
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": str(exc)[:400]}

    @app.post("/api/config/test-wecom")
    def test_wecom() -> dict[str, Any]:
        result = notifier.send_test_message(config, f"打卡链接示例：{config.effective_base_url()}/checkin")
        return {"ok": bool(result.get("ok")), "detail": result}

    # ==================== 对话 ====================
    @app.get("/api/chat/history")
    def chat_history(session_id: str = "default") -> dict[str, Any]:
        return {"ok": True, "messages": agent.history(session_id), "session_id": session_id}

    @app.post("/api/chat")
    def chat(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        session_id = str(payload.get("session_id") or "default")
        message = str(payload.get("message") or "")
        return agent.chat(session_id, message)

    @app.post("/api/chat/reset")
    def chat_reset(payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
        agent.reset(str(payload.get("session_id") or "default"))
        return {"ok": True}

    # ==================== 兜底 ====================
    @app.exception_handler(404)
    async def not_found(request, exc):  # noqa: ANN001
        if request.url.path.startswith("/api/"):
            return JSONResponse({"ok": False, "error": "接口不存在"}, status_code=404)
        return FileResponse(paths.STATIC_DIR / "index.html")

    app.state.store = store
    app.state.config = config
    app.state.agent = agent
    app.state.scheduler = scheduler
    return app


def _view(plan: dict[str, Any], config: ConfigStore) -> dict[str, Any]:
    view = plan_view(plan)
    view["checkin_url"] = checkin.checkin_url(config, plan["id"])
    return view
