"""打卡链接的签发与校验。

链接形如：http://<地址>:<端口>/checkin?t=<签名票据>
票据用 HMAC-SHA256 签名，包含计划 ID、打卡日期、过期时间，
所以链接无法被猜测或篡改，过期后自动失效。
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
from datetime import timedelta
from typing import Any

from . import paths


def _b64encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64decode(text: str) -> bytes:
    padding = "=" * (-len(text) % 4)
    return base64.urlsafe_b64decode(text + padding)


def _sign(secret: str, payload: bytes) -> str:
    return _b64encode(hmac.new(secret.encode("utf-8"), payload, hashlib.sha256).digest())


def make_token(secret: str, plan_id: str, day: str, hours: int = 24) -> str:
    expires = paths.now() + timedelta(hours=max(1, int(hours or 24)))
    payload = {
        "p": plan_id,
        "d": day,
        "e": int(expires.timestamp()),
        "n": paths.new_id("t")[-6:],
    }
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return f"{_b64encode(raw)}.{_sign(secret, raw)}"


def verify_token(secret: str, token: str) -> dict[str, Any] | None:
    if not token or "." not in token:
        return None
    body, signature = token.split(".", 1)
    try:
        raw = _b64decode(body)
    except (ValueError, TypeError):
        return None
    if not hmac.compare_digest(signature, _sign(secret, raw)):
        return None
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return None
    if int(payload.get("e") or 0) < int(paths.now().timestamp()):
        return None
    return payload


def checkin_url(config, plan_id: str, day: str | None = None) -> str:
    day = day or paths.today_str()
    token = make_token(
        config.get("checkin_token_secret", ""),
        plan_id,
        day,
        config.get_int("checkin_token_hours", 24),
    )
    return f"{config.effective_base_url()}/checkin?t={token}"


def render_reminder(plan: dict[str, Any], slot: str, url: str, day_index: int | None = None) -> str:
    """生成企业微信推送的提醒文本。"""
    start = paths.parse_date(plan.get("start_date")) or paths.today()
    days = int(plan.get("days") or 1)
    index = day_index or ((paths.today() - start).days + 1)
    index = max(1, min(days, index))
    daily = [t for t in plan.get("tasks", []) if int(t.get("day") or 0) == 0]
    today_tasks = [t for t in plan.get("tasks", []) if int(t.get("day") or 0) == index]
    checkin = plan.get("checkin", {})
    streak = int(checkin.get("streak") or 0)
    checked_today = paths.today_str() in set(checkin.get("history") or [])

    lines = [
        f"📌 计划提醒 · {plan.get('title')}",
        f"🗓 今天是第 {index}/{days} 天（{paths.today_str()}）",
    ]
    if today_tasks or daily:
        lines.append("✅ 今天要做：")
        for i, task in enumerate(daily + today_tasks, 1):
            prefix = f"{task['time']} " if task.get("time") else ""
            lines.append(f"  {i}. {prefix}{task['title']}")
    else:
        lines.append("✅ 今天没有单独安排，按计划推进即可")
    lines.append(f"⏰ 提醒时间：{slot}")
    if streak:
        spark = f"🔥 已连续打卡 {streak} 天"
        lines.append(f"{spark}（不要断哦）" if not checked_today else "✅ 今日已打卡，火花保持中")
    else:
        lines.append("✨ 今天开始点亮第一次火花")
    lines.append("")
    lines.append("👉 点击签到续火花：" if not checked_today else "👉 查看今天的计划：")
    lines.append(url)
    return "\n".join(lines)
