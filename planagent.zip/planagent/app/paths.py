"""项目内所有路径与通用工具函数。

统一放在这里，避免各模块各写一份 Path(...).parent 的混乱。
"""

from __future__ import annotations

import json
import os
import socket
import sys
import tempfile
import threading
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
STATIC_DIR = BASE_DIR / "static"

CONFIG_PATH = DATA_DIR / "config.json"
PLANS_PATH = DATA_DIR / "plans.json"
STATE_PATH = DATA_DIR / "state.json"
SESSIONS_PATH = DATA_DIR / "sessions.json"
LOG_PATH = DATA_DIR / "planagent.log"

_LOCK = threading.RLock()

DATE_FMT = "%Y-%m-%d"

# Windows 控制台默认是 GBK，日志里的 emoji 会直接抛 UnicodeEncodeError。
# 这里统一把标准输出切到 UTF-8，切不动就退化为替换字符，保证不影响主流程。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except (AttributeError, ValueError, OSError):
        pass


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    STATIC_DIR.mkdir(parents=True, exist_ok=True)


def now() -> datetime:
    return datetime.now()


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def today() -> date:
    return datetime.now().date()


def today_str() -> str:
    return today().strftime(DATE_FMT)


def new_id(prefix: str = "id") -> str:
    stamp = datetime.now().strftime("%Y%m%d%H%M%S")
    return f"{prefix}_{stamp}_{uuid.uuid4().hex[:6]}"


def parse_date(value: Any) -> date | None:
    """把 'YYYY-MM-DD' / 'YYYY/MM/DD' / 'YYYY-MM-DD HH:MM' 解析成 date。"""
    if not value:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value).strip().replace("/", "-").replace(".", "-")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%Y-%m", "%Y%m%d"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def parse_hhmm(value: Any) -> tuple[int, int] | None:
    """把 '8:5' / '08:05' / '0805' / '8点30' 解析成 (hour, minute)。"""
    if value is None:
        return None
    if isinstance(value, (list, tuple)) and len(value) == 2:
        try:
            h, m = int(value[0]), int(value[1])
        except (TypeError, ValueError):
            return None
        return (h, m) if 0 <= h < 24 and 0 <= m < 60 else None
    text = str(value).strip()
    if not text:
        return None
    text = (
        text.replace("：", ":")
        .replace("点", ":")
        .replace("分", "")
        .replace("时", ":")
        .strip(": ")
    )
    if ":" in text:
        parts = text.split(":")
    elif text.isdigit() and len(text) in (3, 4):
        text = text.zfill(4)
        parts = [text[:2], text[2:]]
    else:
        return None
    try:
        h = int(parts[0])
        m = int(parts[1]) if len(parts) > 1 and parts[1] != "" else 0
    except (TypeError, ValueError):
        return None
    if not (0 <= h < 24 and 0 <= m < 60):
        return None
    return h, m


def normalize_hhmm(value: Any, default: str | None = None) -> str | None:
    parsed = parse_hhmm(value)
    if not parsed:
        return default
    return "%02d:%02d" % parsed


def get_lan_ip() -> str:
    """尽力获取本机在局域网中的 IP（用于给手机生成可访问的打卡链接）。"""
    ip = ""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(0.6)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
    except OSError:
        ip = ""
    if not ip or ip.startswith("127."):
        try:
            ip = socket.gethostbyname(socket.gethostname())
        except OSError:
            ip = "127.0.0.1"
    return ip


def read_json(path: Path, default: Any) -> Any:
    with _LOCK:
        if not path.exists():
            return default
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            return default
        if not text.strip():
            return default
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            backup = path.with_suffix(path.suffix + ".bad")
            try:
                path.replace(backup)
            except OSError:
                pass
            return default


def write_json(path: Path, data: Any) -> None:
    """原子写入 JSON，避免中途崩溃把数据写坏。"""
    with _LOCK:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_name = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp_", suffix=".json")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2)
            os.replace(tmp_name, path)
        finally:
            if os.path.exists(tmp_name):
                try:
                    os.remove(tmp_name)
                except OSError:
                    pass


def log(message: str) -> None:
    line = f"[{now_str()}] {message}"
    try:
        print(line, flush=True)
    except (UnicodeEncodeError, ValueError, OSError):
        try:
            sys.stdout.write(line.encode("ascii", "replace").decode("ascii") + "\n")
            sys.stdout.flush()
        except (ValueError, OSError):
            pass
    try:
        ensure_dirs()
        with _LOCK:
            with LOG_PATH.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
    except OSError:
        pass


def weekday_cn(d: date) -> str:
    return "周" + "一二三四五六日"[d.weekday()]


def daterange_days(start: date, count: int) -> list[date]:
    return [start + timedelta(days=i) for i in range(max(0, count))]
