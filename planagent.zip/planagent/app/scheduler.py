"""提醒调度：到点通过企业微信推送提醒 + 打卡链接。

没有引入额外的调度库，用一条后台线程每 20 秒扫一次，
用 data/state.json 记录「哪个计划的哪个时间点今天已经推送过」，避免重复推送。
"""

from __future__ import annotations

import threading
from datetime import datetime, timedelta
from typing import Any

from . import checkin, notifier, paths
from .store import plan_view

TICK_SECONDS = 20


class ReminderScheduler(threading.Thread):
    def __init__(self, config, store):
        super().__init__(daemon=True, name="planagent-scheduler")
        self.config = config
        self.store = store
        self._stop = threading.Event()
        state = paths.read_json(paths.STATE_PATH, {}) or {}
        self.state: dict[str, Any] = state if isinstance(state, dict) else {}
        self.state.setdefault("sent", {})
        self.last_tick: str | None = None
        self.last_error: str | None = None

    # ---------------- 线程 ----------------
    def stop(self) -> None:
        self._stop.set()

    def run(self) -> None:
        paths.log("提醒调度已启动")
        while not self._stop.is_set():
            try:
                self.tick()
                self.last_error = None
            except Exception as exc:  # noqa: BLE001
                self.last_error = str(exc)
                paths.log(f"调度出错：{exc}")
            self._stop.wait(TICK_SECONDS)

    # ---------------- 一轮扫描 ----------------
    def tick(self) -> None:
        self.last_tick = paths.now_str()
        if not self.config.notify_ready():
            return
        now = paths.now()
        today = paths.today_str()
        catch_up = self.config.get_int("catch_up_minutes", 30) * 60
        sent: dict[str, str] = self.state["sent"]
        changed = False

        for plan in self.store.list_plans():
            if plan.get("status") != "active":
                continue
            if not plan.get("notify_enabled", True):
                continue
            for slot in plan.get("reminder_times") or []:
                key = f"{plan['id']}|{today}|{slot}"
                if key in sent:
                    continue
                parsed = paths.parse_hhmm(slot)
                if not parsed:
                    continue
                slot_dt = now.replace(hour=parsed[0], minute=parsed[1], second=0, microsecond=0)
                delta = (now - slot_dt).total_seconds()
                if delta < 0 or delta > catch_up:
                    continue
                result = self.push_reminder(plan, slot)
                sent[key] = paths.now_str()
                changed = True
                if not result.get("ok"):
                    paths.log(f"提醒推送失败：{plan.get('title')} {slot} -> {result.get('errmsg')}")

        # 清理 7 天前的记录
        cutoff = (paths.now() - timedelta(days=7)).strftime("%Y-%m-%d")
        for key in list(sent.keys()):
            parts = key.split("|")
            if len(parts) == 3 and parts[1] < cutoff:
                sent.pop(key, None)
                changed = True

        if changed:
            paths.write_json(paths.STATE_PATH, self.state)

    # ---------------- 推送 ----------------
    def push_reminder(self, plan: dict[str, Any], slot: str | None = None) -> dict[str, Any]:
        slot = slot or (plan.get("reminder_times") or ["09:00"])[0]
        view = plan_view(plan)
        url = checkin.checkin_url(self.config, plan["id"])
        content = checkin.render_reminder(plan, slot, url, view["today_index"])
        return notifier.send_wecom_text(self.config, content, plan.get("webhook") or None)

    def next_reminders(self, limit: int = 5) -> list[dict[str, Any]]:
        """给界面展示「下一次提醒是什么时候」。"""
        now = paths.now()
        upcoming: list[dict[str, Any]] = []
        for plan in self.store.list_plans():
            if plan.get("status") != "active" or not plan.get("notify_enabled", True):
                continue
            for slot in plan.get("reminder_times") or []:
                parsed = paths.parse_hhmm(slot)
                if not parsed:
                    continue
                when = now.replace(hour=parsed[0], minute=parsed[1], second=0, microsecond=0)
                if when <= now:
                    when += timedelta(days=1)
                upcoming.append(
                    {
                        "plan_id": plan["id"],
                        "title": plan.get("title"),
                        "slot": slot,
                        "when": when.strftime("%Y-%m-%d %H:%M"),
                    }
                )
        upcoming.sort(key=lambda item: item["when"])
        return upcoming[:limit]

    def sent_today(self, plan_id: str) -> list[str]:
        today = paths.today_str()
        prefix = f"{plan_id}|{today}|"
        return sorted(key.split("|")[-1] for key in self.state.get("sent", {}) if key.startswith(prefix))
