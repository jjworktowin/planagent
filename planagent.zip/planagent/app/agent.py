"""DeepSeek 计划智能体。

按官方「思考模式」文档实现：
  · base_url = https://api.deepseek.com
  · 思考开关：extra_body={"thinking": {"type": "enabled"/"disabled"}}
  · 思考强度：reasoning_effort = low / high / max
  · 思维链通过 message.reasoning_content 返回
  · 携带 tools 参数的请求，后续轮次必须完整回传 reasoning_content，
    否则 API 会报 400；这里通过整体保存 message 对象来满足该约束。
"""

from __future__ import annotations

import json
from typing import Any

from openai import OpenAI

from . import paths
from .store import plan_view

MAX_TOOL_ROUNDS = 8
HISTORY_LIMIT = 60


def tools_schema() -> list[dict[str, Any]]:
    task_item = {
        "type": "object",
        "properties": {
            "day": {
                "type": "integer",
                "description": "第几天执行（从 1 开始，最大等于计划总天数）；若要每天都做，填 0",
            },
            "time": {
                "type": "string",
                "description": "该任务的提醒时间 HH:MM（24 小时制）；留空表示跟随计划整体提醒时间",
            },
            "title": {"type": "string", "description": "要做的事，动词开头，具体可执行"},
            "detail": {"type": "string", "description": "补充说明：做到什么程度、用什么材料"},
        },
        "required": ["title"],
    }
    plan_fields = {
        "title": {"type": "string", "description": "计划标题，简短有辨识度"},
        "goal": {"type": "string", "description": "用户的原始目标/需求描述"},
        "start_date": {"type": "string", "description": "开始日期 YYYY-MM-DD，默认今天"},
        "days": {"type": "integer", "description": "计划总天数"},
        "reminder_times": {
            "type": "array",
            "items": {"type": "string"},
            "description": "每天的提醒时间点列表，格式 HH:MM，例如 [\"08:00\",\"20:30\"]",
        },
        "notify_enabled": {"type": "boolean", "description": "是否开启企业微信提醒，默认 true"},
        "tasks": {
            "type": "array",
            "items": task_item,
            "description": "计划里每天需要做什么；这是完整列表，会整体替换旧任务",
        },
        "notes": {"type": "string", "description": "额外备注"},
        "status": {"type": "string", "enum": ["active", "paused", "done", "archived"]},
    }
    return [
        {
            "type": "function",
            "function": {
                "name": "create_plan",
                "description": (
                    "创建一个新的计划，并写入计划表。只有在目标、总天数、每天做什么、"
                    "提醒时间都明确后才调用；缺信息时先向用户追问。"
                ),
                "parameters": {
                    "type": "object",
                    "properties": plan_fields,
                    "required": ["title", "days", "reminder_times", "tasks"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "update_plan",
                "description": "修改已有计划（改天数、改提醒时间、改任务、暂停/恢复）。任务字段是整体替换。",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "plan_id": {"type": "string", "description": "要修改的计划 ID"},
                        **plan_fields,
                    },
                    "required": ["plan_id"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "list_plans",
                "description": "列出用户当前所有的计划（含 ID、天数、提醒时间、连续打卡天数）。",
                "parameters": {"type": "object", "properties": {}},
            },
        },
        {
            "type": "function",
            "function": {
                "name": "get_plan",
                "description": "查看某个计划的完整计划表：每天做什么、日期、打卡状态。",
                "parameters": {
                    "type": "object",
                    "properties": {"plan_id": {"type": "string", "description": "计划 ID"}},
                    "required": ["plan_id"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "delete_plan",
                "description": "删除一个计划（用户明确要求删除时才调用）。",
                "parameters": {
                    "type": "object",
                    "properties": {"plan_id": {"type": "string", "description": "计划 ID"}},
                    "required": ["plan_id"],
                },
            },
        },
    ]


def build_system_prompt(store) -> str:
    today = paths.today()
    tomorrow = today.fromordinal(today.toordinal() + 1)
    plans = store.list_plans()
    if plans:
        lines = []
        for plan in plans:
            view = plan_view(plan)
            streak = plan.get("checkin", {}).get("streak", 0)
            lines.append(
                f"- [{plan['id']}] {plan.get('title')}｜{plan.get('days')} 天"
                f"｜{plan.get('start_date')} 起｜提醒 {','.join(plan.get('reminder_times') or [])}"
                f"｜状态 {plan.get('status')}｜连续打卡 {streak} 天"
                f"｜进度 {view['progress']['done']}/{view['progress']['total']}"
            )
        plans_text = "\n".join(lines)
    else:
        plans_text = "（当前还没有任何计划）"

    return f"""你是「计划智能体」，帮用户把模糊的愿望拆成能坚持执行的每日计划，并负责按时推送打卡提醒。

## 当前时间
- 今天：{today.strftime('%Y-%m-%d')}（{paths.weekday_cn(today)}）
- 明天：{tomorrow.strftime('%Y-%m-%d')}

## 用户已有计划
{plans_text}

## 工作流程
1. **先精准识别需求**：目标是什么、周期多长（天数）、每天能投入多少时间、希望几点被提醒、有没有硬性约束。
2. **信息不足就先问**：缺少【计划天数】或【提醒时间】时，用 1~3 个简短问题问清楚，不要凭空编造用户没说过的时间。用户说「你定」时，才自行给出合理默认值并说明。
3. **信息够了就调用 create_plan**：一次性给出完整计划表。任务要具体可执行，每一天都有明确的「需要做什么」，禁止出现「继续努力」「保持状态」这类空话。
4. **创建后用三两句话总结**：总天数、每天提醒时间、今天要做什么。不要复述整张表，界面会自动展示计划表。
5. **要改计划时用 update_plan**：注意 tasks 是整体替换，必须把没被修改的任务一起传回去；不确定时先调用 get_plan 看现状。
6. 用户只是闲聊、问进度、问怎么办时，正常对话即可，不要乱建计划。

## 拆解要求
- `day`：1 表示第 1 天，0 表示「每天都要做」的重复任务。
- `reminder_times`：给 1~3 个时间点，例如 ["08:00","20:30"]；和任务里的 `time` 要能对上。
- 节奏合理：起步温和、中期推进、后期冲刺或复盘；每天任务量匹配用户可投入的时间。
- 天数超过 14 天时，不必逐天写不同任务，可以用「每天重复任务（day=0）」+ 阶段性任务（day=1/7/14/21…）组合，避免计划表冗长。

## 回答风格
中文、简洁、有条理，像一位靠谱的计划教练。适当用 Markdown，但不要长篇大论。"""


class PlannerAgent:
    def __init__(self, config, store):
        self.config = config
        self.store = store
        self._client: OpenAI | None = None
        self._client_signature: tuple[str, str] | None = None
        data = paths.read_json(paths.SESSIONS_PATH, {}) or {}
        self.sessions: dict[str, dict[str, Any]] = data if isinstance(data, dict) else {}

    # ---------------- 客户端 ----------------
    def client(self) -> OpenAI:
        api_key = self.config.get("deepseek_api_key", "")
        if not api_key:
            raise RuntimeError("还没有配置 DeepSeek API Key，请到左侧「设置」里填写。")
        base_url = self.config.get("deepseek_base_url", "https://api.deepseek.com")
        signature = (api_key, base_url)
        if self._client is None or self._client_signature != signature:
            self._client = OpenAI(api_key=api_key, base_url=base_url, timeout=180.0, max_retries=1)
            self._client_signature = signature
        return self._client

    def reset_clients(self) -> None:
        self._client = None
        self._client_signature = None

    # ---------------- 会话 ----------------
    def _session(self, session_id: str) -> dict[str, Any]:
        session = self.sessions.get(session_id)
        if not session:
            session = {"id": session_id, "messages": [], "created_at": paths.now_str()}
            self.sessions[session_id] = session
        session.setdefault("messages", [])
        return session

    def save_sessions(self) -> None:
        paths.write_json(paths.SESSIONS_PATH, self.sessions)

    def reset(self, session_id: str) -> None:
        self.sessions.pop(session_id, None)
        self.save_sessions()

    def history(self, session_id: str) -> list[dict[str, Any]]:
        session = self._session(session_id)
        out = []
        for message in session.get("messages", []):
            role = message.get("role")
            if role not in {"user", "assistant"}:
                continue
            content = message.get("content")
            if not content:
                continue
            out.append(
                {
                    "role": role,
                    "content": content,
                    "reasoning": (message.get("reasoning_content") or "") if role == "assistant" else "",
                }
            )
        return out

    # ---------------- 对话主循环 ----------------
    def chat(self, session_id: str, text: str) -> dict[str, Any]:
        text = (text or "").strip()
        if not text:
            return {"ok": False, "error": "消息内容为空"}
        try:
            client = self.client()
        except RuntimeError as exc:
            return {"ok": False, "error": str(exc)}

        session = self._session(session_id)
        messages: list[dict[str, Any]] = session["messages"]
        messages.append({"role": "user", "content": text})
        self._trim(messages)

        model = self.config.get("deepseek_model", "deepseek-flash")
        thinking = self.config.get_bool("thinking_enabled", True)
        effort = self.config.get("reasoning_effort", "high")

        actions: list[dict[str, Any]] = []
        reasoning_parts: list[str] = []
        contents: list[str] = []
        error: str | None = None

        for _ in range(MAX_TOOL_ROUNDS):
            request: dict[str, Any] = {
                "model": model,
                "messages": self._api_messages(messages),
                "tools": tools_schema(),
            }
            if thinking:
                request["reasoning_effort"] = effort if effort in {"low", "high", "max"} else "high"
                request["extra_body"] = {"thinking": {"type": "enabled"}}
            else:
                request["extra_body"] = {"thinking": {"type": "disabled"}}

            try:
                response = client.chat.completions.create(**request)
            except Exception as exc:  # noqa: BLE001 - 需要把错误原样反馈到界面
                error = _humanize_error(exc)
                break

            if not response.choices:
                error = "模型没有返回任何内容，请稍后再试。"
                break

            message = response.choices[0].message
            assistant_message = _message_to_dict(message)
            messages.append(assistant_message)

            if assistant_message.get("reasoning_content"):
                reasoning_parts.append(assistant_message["reasoning_content"])
            if assistant_message.get("content"):
                contents.append(assistant_message["content"])

            tool_calls = assistant_message.get("tool_calls") or []
            if not tool_calls:
                break

            for call in tool_calls:
                name = (call.get("function") or {}).get("name") or ""
                raw_args = (call.get("function") or {}).get("arguments") or "{}"
                try:
                    args = json.loads(raw_args) if raw_args.strip() else {}
                except json.JSONDecodeError:
                    args = {}
                result, action = self._run_tool(name, args)
                if action:
                    actions.append(action)
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": call.get("id"),
                        "content": json.dumps(result, ensure_ascii=False),
                    }
                )
        else:
            contents.append("（这个需求有点复杂，我先停一下：你可以再说一句更具体的目标或天数，我就继续帮你安排。）")

        self._trim(messages)
        session["updated_at"] = paths.now_str()
        self.save_sessions()

        reply = "\n\n".join([c for c in contents if c.strip()]).strip()
        if error and not reply:
            reply = f"⚠️ 调用 DeepSeek 失败：{error}"
        elif error:
            reply += f"\n\n⚠️ 中途出错：{error}"

        return {
            "ok": error is None,
            "session_id": session_id,
            "reply": reply or "（模型没有返回文本内容）",
            "reasoning": "\n\n".join(reasoning_parts).strip(),
            "actions": actions,
            "plans_changed": any(a.get("type") in {"create_plan", "update_plan", "delete_plan"} for a in actions),
            "error": error,
        }

    # ---------------- 工具执行 ----------------
    def _run_tool(self, name: str, args: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any] | None]:
        try:
            if name == "create_plan":
                plan = self.store.create({**args, "source": "agent"})
                view = plan_view(plan)
                return (
                    {
                        "ok": True,
                        "plan_id": plan["id"],
                        "title": plan["title"],
                        "days": plan["days"],
                        "start_date": plan["start_date"],
                        "reminder_times": plan["reminder_times"],
                        "tasks_count": len(plan["tasks"]),
                        "today_tasks": [t["title"] for t in view["today_tasks"]],
                        "message": "计划已创建并保存到计划表",
                    },
                    {"type": "create_plan", "plan_id": plan["id"], "title": plan["title"]},
                )

            if name == "update_plan":
                plan_id = args.get("plan_id") or ""
                payload = {k: v for k, v in args.items() if k != "plan_id"}
                plan = self.store.update(plan_id, payload)
                if not plan:
                    return {"ok": False, "error": f"没有找到计划 {plan_id}"}, None
                return (
                    {
                        "ok": True,
                        "plan_id": plan["id"],
                        "title": plan["title"],
                        "days": plan["days"],
                        "reminder_times": plan["reminder_times"],
                        "tasks_count": len(plan["tasks"]),
                        "message": "计划已更新",
                    },
                    {"type": "update_plan", "plan_id": plan["id"], "title": plan["title"]},
                )

            if name == "list_plans":
                return {"ok": True, "plans": self.store.summary()}, None

            if name == "get_plan":
                plan = self.store.get(args.get("plan_id") or "")
                if not plan:
                    return {"ok": False, "error": "没有找到该计划"}, None
                view = plan_view(plan)
                rows = [
                    {
                        "day": row["day_index"],
                        "date": row["date"],
                        "weekday": row["weekday"],
                        "state": row["state"],
                        "tasks": [
                            {"time": t.get("time", ""), "title": t["title"], "detail": t.get("detail", "")}
                            for t in row["tasks"] + row["daily_tasks"]
                        ],
                    }
                    for row in view["rows"]
                ]
                return (
                    {
                        "ok": True,
                        "plan": {
                            "id": plan["id"],
                            "title": plan["title"],
                            "days": plan["days"],
                            "start_date": plan["start_date"],
                            "reminder_times": plan["reminder_times"],
                            "status": plan["status"],
                            "checkin": plan.get("checkin", {}),
                            "rows": rows,
                        },
                    },
                    None,
                )

            if name == "delete_plan":
                ok = self.store.delete(args.get("plan_id") or "")
                return (
                    {"ok": ok, "message": "计划已删除" if ok else "没有找到该计划"},
                    {"type": "delete_plan", "plan_id": args.get("plan_id")} if ok else None,
                )

            return {"ok": False, "error": f"未知工具：{name}"}, None
        except Exception as exc:  # noqa: BLE001
            paths.log(f"工具 {name} 执行失败：{exc}")
            return {"ok": False, "error": f"工具执行失败：{exc}"}, None

    # ---------------- 辅助 ----------------
    def _api_messages(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        prepared: list[dict[str, Any]] = [
            {"role": "system", "content": build_system_prompt(self.store)}
        ]
        for message in messages:
            item: dict[str, Any] = {"role": message.get("role")}
            if message.get("role") == "tool":
                item["tool_call_id"] = message.get("tool_call_id")
                item["content"] = message.get("content") or ""
            else:
                item["content"] = message.get("content") or ""
            if message.get("reasoning_content"):
                item["reasoning_content"] = message["reasoning_content"]
            if message.get("tool_calls"):
                item["tool_calls"] = message["tool_calls"]
            prepared.append(item)
        return prepared

    def _trim(self, messages: list[dict[str, Any]], limit: int = HISTORY_LIMIT) -> None:
        if len(messages) <= limit:
            return
        cut = 0
        for index, message in enumerate(messages):
            if message.get("role") == "user" and len(messages) - index <= limit:
                cut = index
                break
        else:
            cut = max(0, len(messages) - limit)
        del messages[:cut]


def _message_to_dict(message) -> dict[str, Any]:
    """把 OpenAI SDK 的 message 对象转成可持久化、可回传给 API 的字典。"""
    data: dict[str, Any] = {"role": "assistant", "content": message.content or ""}
    reasoning = getattr(message, "reasoning_content", None)
    if reasoning:
        data["reasoning_content"] = reasoning
    tool_calls = getattr(message, "tool_calls", None)
    if tool_calls:
        data["tool_calls"] = [
            {
                "id": call.id,
                "type": "function",
                "function": {"name": call.function.name, "arguments": call.function.arguments},
            }
            for call in tool_calls
        ]
    return data


def _humanize_error(exc: Exception) -> str:
    text = str(exc)
    if "401" in text or "Authentication" in text or "invalid_api_key" in text:
        return "API Key 无效或已失效，请到设置里更新 DeepSeek 密钥。"
    if "402" in text or "Insufficient Balance" in text:
        return "账户余额不足，请到 DeepSeek 官网充值。"
    if "429" in text:
        return "请求太频繁，被限流了，稍等几秒再试。"
    if "reasoning_content" in text:
        return "思考模式上下文拼接异常（缺少 reasoning_content），请重试或清空对话。"
    if "Connection" in text or "timed out" in text or "Timeout" in text:
        return "网络连接超时，请检查网络后重试。"
    return text[:400]
