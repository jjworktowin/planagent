"""企业微信机器人推送。

接口就是用户提供的那个地址：
  POST https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=xxx
  body: {"msgtype": "text", "text": {"content": "..."}}
"""

from __future__ import annotations

from typing import Any

import requests

from . import paths

TIMEOUT = 15


def send_wecom_text(config, content: str, webhook: str | None = None) -> dict[str, Any]:
    """发送文本消息，返回 {"ok": bool, "errcode": int, "errmsg": str}。"""
    url = (webhook or config.get("wecom_webhook", "") or "").strip()
    if not url:
        return {"ok": False, "errcode": -1, "errmsg": "未配置企业微信机器人地址"}
    if not url.startswith("http"):
        return {"ok": False, "errcode": -1, "errmsg": "企业微信机器人地址格式不对（应以 http 开头）"}
    if not content.strip():
        return {"ok": False, "errcode": -1, "errmsg": "消息内容为空"}

    body = {"msgtype": "text", "text": {"content": content[:3800]}}
    try:
        resp = requests.post(url, json=body, timeout=TIMEOUT)
    except requests.RequestException as exc:
        paths.log(f"企业微信推送失败(网络): {exc}")
        return {"ok": False, "errcode": -2, "errmsg": f"网络请求失败：{exc}"}

    try:
        data = resp.json()
    except ValueError:
        return {
            "ok": False,
            "errcode": resp.status_code,
            "errmsg": f"返回内容无法解析（HTTP {resp.status_code}）",
        }

    errcode = int(data.get("errcode", -1))
    errmsg = str(data.get("errmsg", ""))
    if errcode == 0:
        paths.log(f"企业微信推送成功：{content.splitlines()[0][:40]}")
        return {"ok": True, "errcode": 0, "errmsg": errmsg or "ok"}
    paths.log(f"企业微信推送被拒绝：errcode={errcode} errmsg={errmsg}")
    return {"ok": False, "errcode": errcode, "errmsg": errmsg or f"errcode={errcode}"}


def send_test_message(config, extra: str = "") -> dict[str, Any]:
    text = (
        "✅ 计划智能体连接成功\n"
        "这条消息来自「计划智能体」的连通性测试。\n"
        f"时间：{paths.now_str()}"
    )
    if extra:
        text += f"\n{extra}"
    return send_wecom_text(config, text)
