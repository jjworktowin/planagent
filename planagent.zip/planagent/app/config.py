"""配置存储：DeepSeek 密钥、企业微信机器人地址、服务地址等。

代码里不写任何密钥：
  · 优先读环境变量（DEEPSEEK_API_KEY / WECOM_WEBHOOK / DEEPSEEK_BASE_URL）
  · 其余的保存在 data/config.json —— 该目录已被 .gitignore 排除，不会进版本库
"""

from __future__ import annotations

import os
import secrets
from typing import Any

from . import paths

DEEPSEEK_BASE_URL_DEFAULT = "https://api.deepseek.com"
DEEPSEEK_MODEL_DEFAULT = "deepseek-flash"

# 这些字段可以用环境变量注入（留空则用网页「设置」里保存的值）
ENV_KEYS = {
    "deepseek_api_key": "DEEPSEEK_API_KEY",
    "deepseek_base_url": "DEEPSEEK_BASE_URL",
    "wecom_webhook": "WECOM_WEBHOOK",
}

# 允许通过界面/接口修改的字段白名单
EDITABLE_KEYS = {
    "deepseek_api_key",
    "deepseek_base_url",
    "deepseek_model",
    "thinking_enabled",
    "reasoning_effort",
    "temperature_free_mode",  # 占位：思考模式下 temperature 不生效
    "wecom_webhook",
    "wecom_webhook_enabled",
    "notify_enabled",
    "catch_up_minutes",
    "public_base_url",
    "host",
    "port",
    "checkin_token_hours",
    "user_name",
    "access_password",
}


def default_config() -> dict[str, Any]:
    return {
        # ---- DeepSeek ----
        # 密钥不写死在代码里：环境变量优先，其次在网页「设置」里填写，存到 data/config.json
        "deepseek_api_key": os.environ.get("DEEPSEEK_API_KEY", ""),
        "deepseek_base_url": os.environ.get("DEEPSEEK_BASE_URL", DEEPSEEK_BASE_URL_DEFAULT),
        "deepseek_model": DEEPSEEK_MODEL_DEFAULT,
        "thinking_enabled": True,
        "reasoning_effort": "high",
        # ---- 企业微信机器人 ----
        "wecom_webhook": os.environ.get("WECOM_WEBHOOK", ""),
        "wecom_webhook_enabled": True,
        # ---- 通知 ----
        "notify_enabled": True,          # 全局通知总开关
        "catch_up_minutes": 30,          # 服务重启后，多久内的提醒仍补发
        # ---- 服务 ----
        "host": "0.0.0.0",
        "port": 8765,
        "public_base_url": "",           # 手机可访问的地址；留空则自动用局域网 IP
        "checkin_token_hours": 24,       # 打卡链接有效期（小时）
        "user_name": "同学",
        "access_password": "",           # 访问口令；为空表示不启用
        # ---- 内部 ----
        "checkin_token_secret": "",
    }


class ConfigStore:
    def __init__(self, path=None):
        self.path = path or paths.CONFIG_PATH
        self._data: dict[str, Any] = {}
        self.load()

    # ---------- 基础读写 ----------
    def load(self) -> dict[str, Any]:
        defaults = default_config()
        stored = paths.read_json(self.path, {}) or {}
        if not isinstance(stored, dict):
            stored = {}
        data = dict(defaults)
        data.update({k: v for k, v in stored.items() if v is not None or k in defaults})
        # 文件里是空值、又设置了环境变量时，用环境变量兜底（服务器上常用这种方式注入密钥）
        for key, env_name in ENV_KEYS.items():
            if os.environ.get(env_name) and not str(data.get(key) or "").strip():
                data[key] = os.environ[env_name]
        if not data.get("checkin_token_secret"):
            data["checkin_token_secret"] = secrets.token_urlsafe(32)
        self._data = data
        self.save()
        return self._data

    def save(self) -> None:
        paths.write_json(self.path, self._data)

    # ---------- 访问 ----------
    @property
    def data(self) -> dict[str, Any]:
        return self._data

    def get(self, key: str, default: Any = None) -> Any:
        value = self._data.get(key, default)
        return default if value is None else value

    def get_int(self, key: str, default: int) -> int:
        try:
            return int(self._data.get(key, default))
        except (TypeError, ValueError):
            return default

    def get_bool(self, key: str, default: bool = False) -> bool:
        value = self._data.get(key, default)
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.strip().lower() in {"1", "true", "yes", "on", "是", "开"}
        return bool(value)

    def update(self, patch: dict[str, Any]) -> dict[str, Any]:
        """只接受白名单字段，返回被实际更新的字段。"""
        changed: dict[str, Any] = {}
        for key, value in (patch or {}).items():
            if key not in EDITABLE_KEYS:
                continue
            if key == "port":
                try:
                    value = int(value)
                except (TypeError, ValueError):
                    continue
            if key == "catch_up_minutes":
                try:
                    value = max(0, min(24 * 60, int(value)))
                except (TypeError, ValueError):
                    continue
            if key == "reasoning_effort" and value not in {"low", "medium", "high", "max"}:
                value = "high"
            if key == "deepseek_api_key":
                value = str(value).strip()
            if key == "wecom_webhook":
                value = str(value).strip()
            if isinstance(value, str):
                value = value.strip()
            if self._data.get(key) != value:
                self._data[key] = value
                changed[key] = value
        if changed:
            self.save()
        return changed

    # ---------- 对外展示（脱敏） ----------
    def public(self) -> dict[str, Any]:
        data = dict(self._data)
        data["deepseek_api_key"] = mask_secret(data.get("deepseek_api_key", ""))
        data["deepseek_api_key_set"] = bool(self._data.get("deepseek_api_key"))
        data["wecom_webhook_set"] = bool(self._data.get("wecom_webhook"))
        data["effective_base_url"] = self.effective_base_url()
        data["access_enabled"] = bool(self._data.get("access_password"))
        data.pop("access_password", None)
        data.pop("checkin_token_secret", None)
        return data

    # ---------- 计算属性 ----------
    def effective_base_url(self) -> str:
        configured = str(self.get("public_base_url", "") or "").strip().rstrip("/")
        if configured:
            return configured
        return f"http://{paths.get_lan_ip()}:{self.get_int('port', 8765)}"

    def notify_ready(self) -> bool:
        return self.get_bool("notify_enabled", True) and self.get_bool(
            "wecom_webhook_enabled", True
        ) and bool(self.get("wecom_webhook", ""))

    def deepseek_ready(self) -> bool:
        return bool(self.get("deepseek_api_key", ""))


def mask_secret(value: str) -> str:
    text = str(value or "")
    if len(text) <= 10:
        return "*" * len(text)
    return f"{text[:6]}{'*' * 8}{text[-4:]}"
