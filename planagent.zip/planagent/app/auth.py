"""访问口令保护。

公网部署时，管理界面必须挡住陌生人；但打卡链接要在企业微信里直接点开，
所以 /checkin 和 /api/checkin/* 必须放行。

口令本身不落 Cookie：Cookie 里存的是由口令派生出来的签名，
所以改口令会让所有旧登录立即失效。
"""

from __future__ import annotations

import hashlib
import hmac

COOKIE_NAME = "planagent_auth"
COOKIE_MAX_AGE = 60 * 60 * 24 * 30  # 30 天

_SALT = b"planagent::access"


def auth_token(password: str) -> str:
    return hmac.new(_SALT, str(password).encode("utf-8"), hashlib.sha256).hexdigest()


def verify(password: str, token: str) -> bool:
    if not password or not token:
        return False
    return hmac.compare_digest(auth_token(password), str(token))


def check_password(password: str, given: str) -> bool:
    """校验用户输入的口令本身。"""
    return hmac.compare_digest(
        str(password).encode("utf-8"), str(given or "").encode("utf-8")
    )


def is_public_path(path: str) -> bool:
    """这些路径不需要登录：打卡链接必须能让手机直接打开。"""
    if path in {"/login", "/logout", "/checkin", "/favicon.ico"}:
        return True
    if path.startswith("/api/checkin"):
        return True
    if path.startswith("/static/"):
        return True
    return False
