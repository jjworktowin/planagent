"""计划智能体 (PlanAgent) 应用包。"""

__all__ = ["__version__"]

__version__ = "1.0.0"
