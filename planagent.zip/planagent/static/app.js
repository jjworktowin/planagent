/* 计划智能体 · 前端逻辑 */

const state = {
  view: "chat",
  plans: [],
  config: {},
  server: {},
  scheduler: {},
  currentPlanId: null,
  currentView: null,
  busy: false,
  sessionId: localStorage.getItem("planagent_session") || "default",
};

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

/* ==================== 基础工具 ==================== */
async function api(path, { method = "GET", body = null } = {}) {
  const options = { method, headers: {} };
  if (body !== null) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  const resp = await fetch(path, options);
  let data;
  try {
    data = await resp.json();
  } catch (err) {
    throw new Error(`服务返回异常（HTTP ${resp.status}）`);
  }
  if (resp.status === 401 && data && data.need_login) {
    // 访问口令失效（例如刚开启口令、或改了口令），回登录页
    location.reload();
    throw new Error("需要登录");
  }
  if (!resp.ok && data && data.detail) {
    throw new Error(typeof data.detail === "string" ? data.detail : JSON.stringify(data.detail));
  }
  return data;
}

function escapeHtml(text) {
  return String(text == null ? "" : text).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

function inlineMd(text) {
  return escapeHtml(text)
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\`([^\`]+)\`/g, "<code>$1</code>")
    .replace(/(https?:\/\/[^\s<）)]+)/g, '<a href="$1" target="_blank" rel="noreferrer">$1</a>');
}

function renderMd(text) {
  const lines = String(text || "").split("\n");
  let html = "";
  let list = [];
  let listTag = null;
  const flush = () => {
    if (list.length) {
      html += `<${listTag}>` + list.map((i) => `<li>${i}</li>`).join("") + `</${listTag}>`;
      list = [];
      listTag = null;
    }
  };
  for (const raw of lines) {
    const line = raw.replace(/\s+$/, "");
    if (!line.trim()) { flush(); continue; }
    let m = /^#{1,4}\s+(.*)$/.exec(line);
    if (m) { flush(); html += `<h3>${inlineMd(m[1])}</h3>`; continue; }
    m = /^\s*[-*+]\s+(.*)$/.exec(line);
    if (m) { if (listTag !== "ul") { flush(); listTag = "ul"; } list.push(inlineMd(m[1])); continue; }
    m = /^\s*\d+[.、)]\s*(.*)$/.exec(line);
    if (m) { if (listTag !== "ol") { flush(); listTag = "ol"; } list.push(inlineMd(m[1])); continue; }
    flush();
    html += `<p>${inlineMd(line)}</p>`;
  }
  flush();
  return html;
}

function toast(message, type = "") {
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.innerHTML = renderMd(message);
  $("#toasts").appendChild(el);
  setTimeout(() => {
    el.style.transition = "opacity .3s, transform .3s";
    el.style.opacity = "0";
    el.style.transform = "translateX(20px)";
    setTimeout(() => el.remove(), 320);
  }, type === "err" ? 6000 : 4000);
}

function celebrate(message) {
  $("#celebrateMsg").textContent = message;
  $("#celebrate").classList.add("show");
  setTimeout(() => $("#celebrate").classList.remove("show"), 2600);
}

function fmtDate(dateStr) {
  if (!dateStr) return "-";
  const d = new Date(dateStr + "T00:00:00");
  if (Number.isNaN(d.getTime())) return dateStr;
  return `${d.getMonth() + 1}月${d.getDate()}日`;
}

/* ==================== 视图切换 ==================== */
function switchView(view) {
  state.view = view;
  $$(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.view === view));
  ["chat", "plans", "settings"].forEach((name) => {
    $(`#view-${name}`).classList.toggle("hidden", name !== view);
  });
  if (view === "settings") fillSettings();
  if (view === "plans" && !state.currentPlanId && state.plans.length) {
    openPlan(state.plans[0].id);
  }
}

/* ==================== 总状态 ==================== */
async function refreshState() {
  try {
    const data = await api("/api/state");
    state.plans = data.plans || [];
    state.config = data.config || {};
    state.server = data.server || {};
    state.scheduler = data.scheduler || {};
    renderSidebar();
    fillSettings();
  } catch (err) {
    toast(`加载状态失败：${err.message}`, "err");
  }
}

function renderSidebar() {
  $("#planCount").textContent = state.plans.filter((p) => p.status === "active").length;

  const notify = $("#globalNotify");
  notify.checked = !!state.config.notify_enabled;
  $("#notifyHint").innerHTML = state.server.notify_ready
    ? "到点推送企业微信提醒"
    : '<span style="color:var(--warn)">未就绪，请到设置里配置</span>';

  const list = $("#planList");
  if (!state.plans.length) {
    list.innerHTML = `<div class="plan-empty">还没有计划<br>去「智能对话」说一句：<br>“帮我做一个 21 天跑步计划”</div>`;
  } else {
    list.innerHTML = state.plans.map((p) => {
      const pct = p.progress ? p.progress.percent : 0;
      const statusText = { active: "进行中", paused: "已暂停", done: "已完成", archived: "已归档" }[p.status] || p.status;
      const fire = p.streak > 0 ? `<span title="连续打卡">🔥 ${p.streak} 天</span>` : "<span>未点亮</span>";
      return `
        <div class="plan-item ${p.id === state.currentPlanId ? "active" : ""}" data-plan="${p.id}">
          <div class="pi-top">
            <span class="pi-title">${escapeHtml(p.title)}</span>
            <span class="badge ${p.status === "active" ? "ok" : ""}">${statusText}</span>
          </div>
          <div class="pi-sub">
            <span>${p.days} 天</span>
            <span>${(p.reminder_times || []).join(" / ")}</span>
            ${fire}
            ${p.checked_in_today ? '<span style="color:var(--ok)">今日已打卡</span>' : ""}
          </div>
          <div class="pi-bar"><i style="width:${pct}%"></i></div>
        </div>`;
    }).join("");
  }

  const next = (state.scheduler.next || [])[0];
  $("#sidebarFoot").innerHTML = `
    <div class="foot-line"><span class="dot ${state.server.notify_ready ? "" : "off"}"></span>
      ${state.server.notify_ready ? "提醒运行中" : "提醒未开启"} · 服务 ${escapeHtml(state.server.base_url || "-")}</div>
    <div class="foot-line">DeepSeek：${state.server.deepseek_ready ? "已连接" : "未配置密钥"}</div>
    <div class="foot-line">${next ? `下一次提醒：${escapeHtml(next.title)} ${next.slot}` : "暂无待办提醒"}</div>`;
}

/* ==================== 对话 ==================== */
function addMessage(role, content, extra = {}) {
  const wrap = document.createElement("div");
  wrap.className = `msg ${role}`;
  const avatar = role === "user" ? "🙋" : "🤖";
  let inner = "";
  if (role === "assistant" && extra.reasoning) {
    inner += `<details class="reasoning"><summary>💭 思考过程（DeepSeek 思考模式）</summary>
      <div class="r-body">${escapeHtml(extra.reasoning)}</div></details>`;
  }
  inner += renderMd(content);
  if (extra.actions && extra.actions.length) {
    inner += `<div class="action-chips">` + extra.actions.map((a) => {
      const label = { create_plan: "已创建计划", update_plan: "已更新计划", delete_plan: "已删除计划" }[a.type] || a.type;
      const clickable = a.plan_id && a.type !== "delete_plan" ? "clickable" : "";
      return `<span class="chip ${clickable}" data-open-plan="${a.plan_id || ""}">${label}：${escapeHtml(a.title || a.plan_id || "")}</span>`;
    }).join("") + `</div>`;
  }
  wrap.innerHTML = `<div class="avatar">${avatar}</div><div class="bubble">${inner}</div>`;
  $("#chatMessages").appendChild(wrap);
  scrollChat();
}

function scrollChat() {
  const box = $("#chatScroll");
  box.scrollTop = box.scrollHeight;
}

function showTyping() {
  const el = document.createElement("div");
  el.className = "msg";
  el.id = "typing";
  el.innerHTML = `<div class="avatar">🤖</div>
    <div class="bubble"><div class="typing"><span class="dots"><span></span><span></span><span></span></span>
    <span id="typingText">正在深度思考，读取你的需求…</span></div></div>`;
  $("#chatMessages").appendChild(el);
  scrollChat();
  const hints = [
    "正在深度思考，读取你的需求…",
    "正在拆解目标，规划每一天要做什么…",
    "正在安排合理的提醒时间…",
    "马上就好，正在生成计划表…",
  ];
  let i = 0;
  return setInterval(() => {
    i = (i + 1) % hints.length;
    const t = document.getElementById("typingText");
    if (t) t.textContent = hints[i];
  }, 3500);
}

function hideTyping() {
  const el = document.getElementById("typing");
  if (el) el.remove();
}

async function sendMessage(text) {
  text = (text || "").trim();
  if (!text || state.busy) return;
  state.busy = true;
  $("#btnSend").disabled = true;
  addMessage("user", text);
  $("#chatInput").value = "";
  autoGrow($("#chatInput"));
  const timer = showTyping();

  try {
    const data = await api("/api/chat", {
      method: "POST",
      body: { session_id: state.sessionId, message: text },
    });
    hideTyping();
    if (!data.ok && data.error && !data.reply) {
      addMessage("assistant", `⚠️ ${data.error}`, {});
    } else {
      addMessage("assistant", data.reply || "（没有返回内容）", {
        reasoning: data.reasoning,
        actions: data.actions,
      });
    }
    if (data.plans_changed) {
      await refreshState();
      const newest = data.actions.find((a) => a.type === "create_plan");
      if (newest && newest.plan_id) {
        state.currentPlanId = newest.plan_id;
        renderSidebar();
      }
    }
  } catch (err) {
    hideTyping();
    addMessage("assistant", `⚠️ 请求失败：${err.message}`, {});
  } finally {
    clearInterval(timer);
    state.busy = false;
    $("#btnSend").disabled = false;
    $("#chatInput").focus();
  }
}

async function loadHistory() {
  try {
    const data = await api(`/api/chat/history?session_id=${encodeURIComponent(state.sessionId)}`);
    $("#chatMessages").innerHTML = "";
    if (!data.messages || !data.messages.length) {
      addMessage(
        "assistant",
        "你好，我是**计划智能体** 🔥\n\n告诉我你想做成什么事，我会帮你拆成一张能坚持的计划表。\n\n为了安排得更准，你可以顺手说清这几点：\n\n1. 目标是什么（例如：21 天养成跑步习惯）\n2. 计划多少天\n3. 每天要做的事 / 能投入多久\n4. 希望几点被提醒\n\n说完我就把计划存下来，到点用企业微信喊你打卡。",
        {}
      );
    } else {
      data.messages.forEach((m) => addMessage(m.role, m.content, { reasoning: m.reasoning }));
    }
  } catch (err) {
    toast(`加载历史失败：${err.message}`, "err");
  }
}

/* ==================== 计划详情 ==================== */
async function openPlan(planId) {
  if (!planId) return;
  state.currentPlanId = planId;
  renderSidebar();
  switchView("plans");
  try {
    const data = await api(`/api/plans/${planId}`);
    state.currentView = data;
    renderPlanDetail(data);
  } catch (err) {
    toast(`打开计划失败：${err.message}`, "err");
  }
}

function statusBadge(status) {
  const map = {
    active: ["进行中", "ok"], paused: ["已暂停", "warn"],
    done: ["已完成", "ok"], archived: ["已归档", ""],
  };
  const [text, cls] = map[status] || [status, ""];
  return `<span class="badge ${cls}">${text}</span>`;
}

function stateBadge(row) {
  if (row.state === "done") return `<span class="badge ok">✅ 已打卡</span>`;
  if (row.state === "today") return `<span class="badge warn">今天 · 待打卡</span>`;
  if (row.state === "missed") return `<span class="badge err">已错过</span>`;
  return `<span class="badge">待开始</span>`;
}

function taskCell(tasks) {
  if (!tasks || !tasks.length) return '<span class="task-detail">—</span>';
  return tasks.map((t) => {
    const time = t.time ? `<code>${escapeHtml(t.time)}</code> ` : "";
    const detail = t.detail ? `<div class="task-detail">${escapeHtml(t.detail)}</div>` : "";
    return `<div>${time}${escapeHtml(t.title)}${detail}</div>`;
  }).join("");
}

function renderPlanDetail(view) {
  const plan = view.plan;
  const rows = view.rows || [];
  const ci = plan.checkin || {};
  const progress = view.progress || { done: 0, total: plan.days, percent: 0 };
  const times = (plan.reminder_times || []).join(", ");

  const taskRows = (plan.tasks || []).map((t, index) => `
    <tr data-task-row="${index}">
      <td class="col-day"><input type="number" min="0" value="${t.day}" data-f="day" title="0 = 每天重复" /></td>
      <td class="col-time"><input type="time" value="${t.time || ""}" data-f="time" /></td>
      <td><input type="text" value="${escapeHtml(t.title)}" data-f="title" placeholder="要做什么" /></td>
      <td><input type="text" value="${escapeHtml(t.detail || "")}" data-f="detail" placeholder="做到什么程度 / 补充说明" /></td>
      <td class="col-op"><button class="mini-btn" data-del-task="${index}" title="删除">✕</button></td>
    </tr>`).join("");

  const tableRows = rows.map((row) => `
    <tr class="${row.is_today ? "today" : ""} ${row.state}">
      <td>第 ${row.day_index} 天</td>
      <td>${fmtDate(row.date)}<div class="task-detail">${row.weekday}</div></td>
      <td>${(plan.reminder_times || []).join("<br>")}</td>
      <td>${taskCell(row.daily_tasks.concat(row.tasks))}</td>
      <td>${stateBadge(row)}</td>
    </tr>`).join("");

  $("#planDetail").innerHTML = `
    <div class="detail-card">
      <div class="detail-head">
        <h3>${escapeHtml(plan.title)}</h3>
        ${statusBadge(plan.status)}
        ${ci.streak ? `<span class="badge fire">🔥 连续 ${ci.streak} 天</span>` : ""}
        <div class="detail-actions">
          <button class="primary-btn" id="btnCheckin">${view.checked_in_today ? "今日已打卡" : "立即打卡"}</button>
          <button class="ghost-btn" id="btnPush">立即推送提醒</button>
          <button class="ghost-btn" id="btnCopyLink">复制打卡链接</button>
          <button class="ghost-btn" id="btnToggleStatus">${plan.status === "active" ? "暂停计划" : "恢复计划"}</button>
          <button class="danger-btn" id="btnDeletePlan">删除</button>
        </div>
      </div>
      <div class="stats">
        <div class="stat"><strong>${progress.done}/${progress.total}</strong><small>已完成天数</small></div>
        <div class="stat"><strong>🔥 ${ci.streak || 0}</strong><small>连续打卡（当前火花）</small></div>
        <div class="stat"><strong>${ci.best || 0}</strong><small>最长连续</small></div>
        <div class="stat"><strong>${ci.total || 0}</strong><small>累计打卡</small></div>
        <div class="stat"><strong>${ci.broken || 0}</strong><small>断签次数</small></div>
      </div>
      <div class="progress-line"><i style="width:${progress.percent}%"></i></div>
      <div class="task-detail">开始日期 ${plan.start_date} · 计划 ${plan.days} 天 · 提醒时间 ${escapeHtml(times)}</div>

      <div class="section-title"><h4>✏️ 修改计划</h4><span>改完记得点「保存修改」</span></div>
      <div class="form-grid">
        <label class="field"><span>计划标题</span><input type="text" id="fTitle" value="${escapeHtml(plan.title)}" /></label>
        <label class="field"><span>开始日期</span><input type="date" id="fStart" value="${plan.start_date}" /></label>
        <label class="field"><span>计划天数</span><input type="number" id="fDays" min="1" max="365" value="${plan.days}" /></label>
        <label class="field"><span>提醒时间（逗号分隔）</span><input type="text" id="fTimes" value="${escapeHtml(times)}" placeholder="08:00, 20:30" /></label>
      </div>
      <div class="field" style="margin-top:12px">
        <span>目标描述</span>
        <textarea id="fGoal" rows="2" placeholder="用户最初的需求描述">${escapeHtml(plan.goal || "")}</textarea>
      </div>
      <div class="switch-row" style="margin-top:12px;background:#131823;border:1px solid var(--line);border-radius:12px;padding:11px 12px">
        <div class="switch-text">
          <strong>开启这个计划的通知</strong>
          <small>到点用企业微信推送今天的任务和打卡链接</small>
        </div>
        <label class="switch"><input type="checkbox" id="fNotify" ${plan.notify_enabled ? "checked" : ""} /><span class="slider"></span></label>
      </div>

      <div class="section-title">
        <h4>🧩 每天需要做什么</h4>
        <button class="mini-btn" id="btnAddTask">＋ 添加任务</button>
      </div>
      <table class="tbl">
        <thead><tr><th class="col-day">第几天</th><th class="col-time">时间</th><th>要做的事</th><th>补充说明</th><th class="col-op"></th></tr></thead>
        <tbody id="taskBody">${taskRows || ""}</tbody>
      </table>
      <div class="task-detail" style="margin-top:6px">「第几天」填 0 表示每天都做；填 3 表示只在第 3 天做。</div>
      <div class="card-actions">
        <button class="primary-btn" id="btnSavePlan">保存修改</button>
        <button class="ghost-btn" id="btnRevertPlan">放弃修改</button>
      </div>
    </div>

    <div class="detail-card">
      <div class="section-title"><h4>📅 计划表</h4><span>共 ${rows.length} 天，绿色为已打卡</span></div>
      <table class="tbl">
        <thead><tr><th>天数</th><th>日期</th><th>提醒</th><th>今天要做</th><th>打卡状态</th></tr></thead>
        <tbody>${tableRows}</tbody>
      </table>
    </div>`;

  bindPlanDetail(view);
}

function collectTaskRows() {
  return $$("#taskBody tr").map((tr) => {
    const get = (f) => {
      const el = tr.querySelector(`[data-f="${f}"]`);
      return el ? el.value.trim() : "";
    };
    return {
      day: parseInt(get("day") || "0", 10) || 0,
      time: get("time"),
      title: get("title"),
      detail: get("detail"),
    };
  }).filter((t) => t.title);
}

async function savePlan() {
  const planId = state.currentPlanId;
  if (!planId) return;
  const payload = {
    title: $("#fTitle").value.trim(),
    start_date: $("#fStart").value,
    days: parseInt($("#fDays").value, 10) || 1,
    reminder_times: $("#fTimes").value,
    goal: $("#fGoal").value.trim(),
    notify_enabled: $("#fNotify").checked,
    tasks: collectTaskRows(),
  };
  try {
    const data = await api(`/api/plans/${planId}`, { method: "PUT", body: payload });
    state.currentView = data;
    renderPlanDetail(data);
    await refreshState();
    toast("计划已保存 ✅", "ok");
  } catch (err) {
    toast(`保存失败：${err.message}`, "err");
  }
}

function bindPlanDetail(view) {
  const plan = view.plan;

  $("#btnSavePlan").onclick = savePlan;
  $("#btnRevertPlan").onclick = () => openPlan(plan.id);
  $("#btnAddTask").onclick = () => {
    const body = $("#taskBody");
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="col-day"><input type="number" min="0" value="0" data-f="day" /></td>
      <td class="col-time"><input type="time" value="" data-f="time" /></td>
      <td><input type="text" value="" data-f="title" placeholder="要做什么" /></td>
      <td><input type="text" value="" data-f="detail" placeholder="补充说明" /></td>
      <td class="col-op"><button class="mini-btn" data-del-task="new">✕</button></td>`;
    body.appendChild(tr);
  };

  $("#btnCheckin").onclick = async () => {
    try {
      const data = await api(`/api/plans/${plan.id}/checkin`, { method: "POST", body: {} });
      if (data.already) {
        toast(data.message || "今天已经打过卡了");
      } else {
        celebrate(`${plan.title}\n${data.message}`);
      }
      await refreshState();
      openPlan(plan.id);
    } catch (err) {
      toast(`打卡失败：${err.message}`, "err");
    }
  };

  $("#btnPush").onclick = async () => {
    try {
      const data = await api(`/api/plans/${plan.id}/push`, { method: "POST", body: {} });
      toast(data.ok ? "已推送到企业微信群，去点链接签到试试 🔥" : `推送失败：${data.detail && data.detail.errmsg}`, data.ok ? "ok" : "err");
    } catch (err) {
      toast(`推送失败：${err.message}`, "err");
    }
  };

  $("#btnCopyLink").onclick = async () => {
    try {
      const data = await api(`/api/plans/${plan.id}/link`);
      await copyText(data.url);
      toast(`打卡链接已复制：\n${data.url}`, "ok");
    } catch (err) {
      toast(`获取链接失败：${err.message}`, "err");
    }
  };

  $("#btnToggleStatus").onclick = async () => {
    const next = plan.status === "active" ? "paused" : "active";
    try {
      await api(`/api/plans/${plan.id}/status`, { method: "POST", body: { status: next } });
      await refreshState();
      openPlan(plan.id);
      toast(next === "paused" ? "计划已暂停，不再提醒" : "计划已恢复", "ok");
    } catch (err) {
      toast(`操作失败：${err.message}`, "err");
    }
  };

  $("#btnDeletePlan").onclick = async () => {
    if (!confirm(`确定删除「${plan.title}」吗？删掉后打卡记录也会一起消失。`)) return;
    try {
      await api(`/api/plans/${plan.id}`, { method: "DELETE" });
      state.currentPlanId = null;
      state.currentView = null;
      await refreshState();
      $("#planDetail").innerHTML = `<div class="empty-state"><div class="empty-emoji">🗑️</div><h3>计划已删除</h3><p>可以继续和智能体对话制定新计划。</p></div>`;
      toast("计划已删除", "ok");
    } catch (err) {
      toast(`删除失败：${err.message}`, "err");
    }
  };
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch (err) {
    const ta = document.createElement("textarea");
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
}

function blankPlanEditor() {
  const today = new Date().toISOString().slice(0, 10);
  const view = {
    plan: {
      id: null,
      title: "新计划",
      goal: "",
      start_date: today,
      days: 7,
      reminder_times: ["09:00"],
      notify_enabled: true,
      status: "active",
      tasks: [],
      checkin: {},
    },
    rows: [],
    progress: { done: 0, total: 7, percent: 0 },
    checked_in_today: false,
  };
  state.currentPlanId = null;
  $("#planDetail").innerHTML = `
    <div class="detail-card">
      <div class="section-title"><h4>🆕 新建计划</h4><span>填好后点创建</span></div>
      <div class="form-grid">
        <label class="field"><span>计划标题</span><input type="text" id="nTitle" value="" placeholder="例如：21 天跑步习惯" /></label>
        <label class="field"><span>开始日期</span><input type="date" id="nStart" value="${today}" /></label>
        <label class="field"><span>计划天数</span><input type="number" id="nDays" min="1" max="365" value="7" /></label>
        <label class="field"><span>提醒时间（逗号分隔）</span><input type="text" id="nTimes" value="09:00" /></label>
      </div>
      <div class="field" style="margin-top:12px">
        <span>目标描述</span>
        <textarea id="nGoal" rows="2" placeholder="想达成什么？"></textarea>
      </div>
      <div class="section-title"><h4>🧩 每天需要做什么</h4><button class="mini-btn" id="btnAddTaskNew">＋ 添加任务</button></div>
      <table class="tbl">
        <thead><tr><th class="col-day">第几天</th><th class="col-time">时间</th><th>要做的事</th><th>补充说明</th><th class="col-op"></th></tr></thead>
        <tbody id="taskBody"></tbody>
      </table>
      <div class="card-actions">
        <button class="primary-btn" id="btnCreatePlan">创建计划</button>
      </div>
    </div>`;

  const addRow = (day = 0) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="col-day"><input type="number" min="0" value="${day}" data-f="day" /></td>
      <td class="col-time"><input type="time" value="" data-f="time" /></td>
      <td><input type="text" value="" data-f="title" placeholder="要做什么" /></td>
      <td><input type="text" value="" data-f="detail" placeholder="补充说明" /></td>
      <td class="col-op"><button class="mini-btn" data-del-task="new">✕</button></td>`;
    $("#taskBody").appendChild(tr);
  };
  addRow(0);
  $("#btnAddTaskNew").onclick = () => addRow(0);
  $("#btnCreatePlan").onclick = async () => {
    const title = $("#nTitle").value.trim();
    if (!title) return toast("先给计划起个名字吧", "err");
    try {
      const data = await api("/api/plans", {
        method: "POST",
        body: {
          title,
          start_date: $("#nStart").value,
          days: parseInt($("#nDays").value, 10) || 1,
          reminder_times: $("#nTimes").value,
          goal: $("#nGoal").value.trim(),
          tasks: collectTaskRows(),
        },
      });
      await refreshState();
      toast("计划已创建 ✅", "ok");
      openPlan(data.plan.id);
    } catch (err) {
      toast(`创建失败：${err.message}`, "err");
    }
  };
}

/* ==================== 设置 ==================== */
function fillSettings() {
  const cfg = state.config || {};
  if (cfg.deepseek_api_key === undefined && cfg.deepseek_model === undefined) return;
  $("#cfgApiKeyMasked").textContent = cfg.deepseek_api_key || "-";
  $("#cfgBaseUrl").value = cfg.deepseek_base_url || "https://api.deepseek.com";
  $("#cfgModel").value = cfg.deepseek_model || "deepseek-flash";
  $("#cfgEffort").value = cfg.reasoning_effort || "high";
  $("#cfgThinking").checked = !!cfg.thinking_enabled;
  $("#cfgWebhook").value = cfg.wecom_webhook || "";
  $("#cfgWebhookEnabled").checked = !!cfg.wecom_webhook_enabled;
  $("#cfgNotifyEnabled").checked = !!cfg.notify_enabled;
  $("#cfgCatchUp").value = cfg.catch_up_minutes != null ? cfg.catch_up_minutes : 30;
  $("#cfgTokenHours").value = cfg.checkin_token_hours != null ? cfg.checkin_token_hours : 24;
  $("#cfgPublicUrl").value = cfg.public_base_url || "";

  const dsBadge = $("#dsBadge");
  dsBadge.textContent = cfg.deepseek_api_key_set ? "已配置" : "未配置";
  dsBadge.className = `badge ${cfg.deepseek_api_key_set ? "ok" : "err"}`;
  const wcBadge = $("#wcBadge");
  wcBadge.textContent = cfg.wecom_webhook_set ? "已配置" : "未配置";
  wcBadge.className = `badge ${cfg.wecom_webhook_set ? "ok" : "err"}`;

  const accessBadge = $("#accessBadge");
  accessBadge.textContent = cfg.access_enabled ? "已开启" : "未开启";
  accessBadge.className = `badge ${cfg.access_enabled ? "ok" : ""}`;
}

async function saveConfig(patch, label) {
  try {
    const data = await api("/api/config", { method: "POST", body: patch });
    state.config = data.config;
    fillSettings();
    renderSidebar();
    toast(`${label}已保存 ✅${data.changed.length ? "" : "（没有变化）"}`, "ok");
  } catch (err) {
    toast(`保存失败：${err.message}`, "err");
  }
}

/* ==================== 事件绑定 ==================== */
function autoGrow(el) {
  el.style.height = "auto";
  el.style.height = Math.min(el.scrollHeight, 150) + "px";
}

function init() {
  $$(".nav-item").forEach((btn) => btn.addEventListener("click", () => switchView(btn.dataset.view)));

  // 任务行的删除 / 计划芯片跳转都用统一的事件委托，避免每次重渲染重复注册
  $("#planDetail").addEventListener("click", (event) => {
    const del = event.target.closest("[data-del-task]");
    if (del) {
      const tr = del.closest("tr");
      if (tr) tr.remove();
      return;
    }
    const chip = event.target.closest("[data-open-plan]");
    if (chip && chip.dataset.openPlan) openPlan(chip.dataset.openPlan);
  });

  $("#btnSend").onclick = () => sendMessage($("#chatInput").value);
  $("#chatInput").addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      sendMessage($("#chatInput").value);
    }
  });
  $("#chatInput").addEventListener("input", (event) => autoGrow(event.target));

  $("#quickChips").addEventListener("click", (event) => {
    const btn = event.target.closest("button[data-text]");
    if (btn) sendMessage(btn.dataset.text);
  });

  $("#btnResetChat").onclick = async () => {
    if (!confirm("确定清空当前对话记录吗？（计划不会丢）")) return;
    await api("/api/chat/reset", { method: "POST", body: { session_id: state.sessionId } });
    loadHistory();
    toast("对话已清空", "ok");
  };

  $("#chatMessages").addEventListener("click", (event) => {
    const chip = event.target.closest("[data-open-plan]");
    if (chip && chip.dataset.openPlan) openPlan(chip.dataset.openPlan);
  });

  $("#planList").addEventListener("click", (event) => {
    const item = event.target.closest("[data-plan]");
    if (item) openPlan(item.dataset.plan);
  });

  $("#btnNewPlan").onclick = () => { switchView("plans"); blankPlanEditor(); };
  $("#btnBlankPlan").onclick = () => { switchView("plans"); blankPlanEditor(); };
  $("#btnReloadPlans").onclick = async () => {
    await refreshState();
    if (state.currentPlanId) openPlan(state.currentPlanId);
    toast("已刷新", "ok");
  };

  $("#globalNotify").onchange = async (event) => {
    const on = event.target.checked;
    await saveConfig({ notify_enabled: on }, on ? "通知总开关" : "通知总开关");
    toast(on ? "通知已开启，到点会推送提醒 🔔" : "通知已关闭", on ? "ok" : "");
  };

  $("#btnEye").onclick = () => {
    const input = $("#cfgApiKey");
    input.type = input.type === "password" ? "text" : "password";
  };

  $("#btnSaveDeepseek").onclick = () => {
    const patch = {
      deepseek_base_url: $("#cfgBaseUrl").value.trim(),
      deepseek_model: $("#cfgModel").value.trim(),
      thinking_enabled: $("#cfgThinking").checked,
      reasoning_effort: $("#cfgEffort").value,
    };
    const key = $("#cfgApiKey").value.trim();
    if (key) patch.deepseek_api_key = key;
    saveConfig(patch, "DeepSeek 配置").then(() => { $("#cfgApiKey").value = ""; });
  };

  $("#btnTestDeepseek").onclick = async () => {
    const btn = $("#btnTestDeepseek");
    btn.disabled = true;
    btn.textContent = "测试中…";
    try {
      const data = await api("/api/config/test-deepseek", { method: "POST", body: {} });
      if (data.ok) {
        toast(`✅ 连接成功（${data.model}）\n模型回复：${data.reply}`, "ok");
      } else {
        toast(`❌ 连接失败：${data.error}`, "err");
      }
    } catch (err) {
      toast(`测试失败：${err.message}`, "err");
    } finally {
      btn.disabled = false;
      btn.textContent = "测试连接";
    }
  };

  $("#btnSaveWecom").onclick = () => saveConfig({
    wecom_webhook: $("#cfgWebhook").value.trim(),
    wecom_webhook_enabled: $("#cfgWebhookEnabled").checked,
  }, "企业微信配置");

  $("#btnTestWecom").onclick = async () => {
    const btn = $("#btnTestWecom");
    btn.disabled = true;
    btn.textContent = "发送中…";
    try {
      await saveConfig({ wecom_webhook: $("#cfgWebhook").value.trim() }, "企业微信地址");
      const data = await api("/api/config/test-wecom", { method: "POST", body: {} });
      toast(data.ok ? "✅ 测试消息已发送到企业微信群，去看看" : `❌ 发送失败：${data.detail && data.detail.errmsg}`, data.ok ? "ok" : "err");
    } catch (err) {
      toast(`发送失败：${err.message}`, "err");
    } finally {
      btn.disabled = false;
      btn.textContent = "发送测试消息";
    }
  };

  $("#btnSaveServer").onclick = () => saveConfig({
    notify_enabled: $("#cfgNotifyEnabled").checked,
    catch_up_minutes: parseInt($("#cfgCatchUp").value, 10) || 0,
    checkin_token_hours: parseInt($("#cfgTokenHours").value, 10) || 24,
    public_base_url: $("#cfgPublicUrl").value.trim(),
  }, "提醒设置");

  $("#btnCopySample").onclick = async () => {
    const url = `${(state.server.base_url || "").replace(/\/$/, "")}/checkin`;
    await copyText(url);
    toast(`示例地址已复制：\n${url}\n\n（真实打卡链接带签名，会自动生成）`, "ok");
  };

  $("#btnEyeAccess").onclick = () => {
    const input = $("#cfgAccess");
    input.type = input.type === "password" ? "text" : "password";
  };

  $("#btnSaveAccess").onclick = async () => {
    const password = $("#cfgAccess").value.trim();
    if (!password) return toast("请先输入要设置的访问口令", "err");
    if (password.length < 4) return toast("口令太短了，建议至少 6 位", "err");
    await saveConfig({ access_password: password }, "访问口令");
    // 用新口令登录一次，否则当前这一页下一次请求就会被挡在登录页
    try {
      await fetch("/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
    } catch (err) { /* 忽略：下面的刷新会重新走登录 */ }
    $("#cfgAccess").value = "";
    await refreshState();
    toast("访问口令已开启，之后打开网站需要输入口令 🔒", "ok");
  };

  $("#btnDisableAccess").onclick = async () => {
    if (!confirm("确定关闭访问口令吗？关闭后任何知道网址的人都能打开这个页面。")) return;
    await saveConfig({ access_password: "" }, "访问口令");
    toast("访问口令已关闭，网站恢复公开访问", "");
  };

  $("#btnLogout").onclick = async () => {
    try {
      await fetch("/logout", { method: "POST" });
    } catch (err) { /* 忽略 */ }
    location.reload();
  };

  refreshState().then(loadHistory);
}

document.addEventListener("DOMContentLoaded", init);
